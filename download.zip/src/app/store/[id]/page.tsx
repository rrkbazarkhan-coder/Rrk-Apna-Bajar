
'use client';

import { useApp } from '@/hooks/use-app';
import { useParams, notFound, useRouter } from 'next/navigation';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { ProductGrid } from '@/components/product-grid';
import Image from 'next/image';
import { ArrowLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';

export default function StorePage() {
    const { stores, products } = useApp();
    const params = useParams();
    const router = useRouter();
    const storeId = parseInt(params.id as string, 10);

    const store = stores.find(s => s.id === storeId);

    if (!store) {
        return notFound();
    }

    const storeProducts = products.filter(p => p.storeId === storeId);

    return (
        <div className="space-y-6">
             <div className="flex items-center gap-4">
                 <Button variant="outline" size="icon" onClick={() => router.back()}>
                    <ArrowLeft className="h-4 w-4" />
                </Button>
                <h1 className="text-3xl font-bold font-headline text-primary">{store.name}</h1>
            </div>

            <Card className="overflow-hidden">
                <div className="relative h-48 w-full bg-muted">
                     <Image
                        src={`https://picsum.photos/seed/${store.id}/1200/400`}
                        alt={`${store.name} banner`}
                        fill
                        className="object-cover"
                        data-ai-hint="store banner"
                    />
                </div>
                <CardContent className="p-6">
                    <div className="flex items-start gap-6 -mt-16">
                        <Avatar className="w-24 h-24 border-4 border-background ring-2 ring-primary">
                            <AvatarImage src={store.sellerPhotoUrl} alt={store.sellerName} />
                            <AvatarFallback>{store.sellerName.charAt(0)}</AvatarFallback>
                        </Avatar>
                        <div className="pt-16">
                            <h2 className="text-xl font-bold">{store.name}</h2>
                            <p className="text-sm text-muted-foreground">Managed by {store.sellerName}</p>
                        </div>
                    </div>
                </CardContent>
            </Card>

            <div>
                <h3 className="text-2xl font-headline font-bold mb-4">All Products from {store.name}</h3>
                {storeProducts.length > 0 ? (
                    <ProductGrid products={storeProducts} selectedCategory="All" />
                ) : (
                    <div className="text-center py-10 border rounded-lg">
                        <p className="text-muted-foreground">This store has not listed any products yet.</p>
                    </div>
                )}
            </div>
        </div>
    )
}
