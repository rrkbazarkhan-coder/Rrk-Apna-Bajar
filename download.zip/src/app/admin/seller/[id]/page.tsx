
'use client';

import { useApp } from '@/hooks/use-app';
import { useParams, notFound, useRouter } from 'next/navigation';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import Image from 'next/image';
import { Button } from '@/components/ui/button';
import { ArrowLeft, Mail, Phone, MapPin, ShieldCheck, ShieldOff, ShieldAlert, Home, CalendarIcon, FileText, Send } from 'lucide-react';
import type { Order, Store } from '@/lib/types';
import { useToast } from '@/hooks/use-toast';
import { format, formatDistanceToNow } from 'date-fns';
import { Dialog, DialogContent, DialogTrigger } from '@/components/ui/dialog';
import { OrderBill } from '@/components/order-bill';
import { ShippingLabel } from '@/components/shipping-label';


export default function SellerDetailPage() {
    const { stores, products, orders, updateStoreStatus } = useApp();
    const router = useRouter();
    const params = useParams();
    const { toast } = useToast();
    const sellerId = parseInt(params.id as string, 10);

    const store = stores.find(s => s.id === sellerId);

    if (!store) {
        return notFound();
    }

    const sellerProducts = products.filter(p => p.storeId === store.id);
    const sellerProductIds = sellerProducts.map(p => p.id);

    const sellerOrders = orders.filter(order => 
        order.items.some(item => {
            const product = products.find(p => p.name === item.name);
            return product ? sellerProductIds.includes(product.id) : false;
        })
    );

    const totalRevenue = sellerOrders.reduce((acc, order) => acc + order.total, 0);

    const statusVariantMap: { [key: string]: "default" | "secondary" | "destructive" } = {
        'Delivered': 'default',
        'Pending': 'secondary',
        'Confirmed': 'default',
        'Cancelled': 'destructive',
    };

    const handleBlock = () => {
        updateStoreStatus(store.id, 'blocked');
        toast({
            title: "Seller Blocked",
            description: `${store.sellerName} has been blocked. Their products will not be visible.`,
            variant: "destructive",
        });
    };

    const handleUnblock = () => {
        updateStoreStatus(store.id, 'active');
        toast({
            title: "Seller Unblocked",
            description: `${store.sellerName} has been unblocked. Their products are now visible.`,
        });
    };
    
    const registrationDate = new Date(store.createdAt);

    return (
        <div className="max-w-6xl mx-auto space-y-8">
            <header className="flex items-center gap-4">
                <Button variant="outline" size="icon" onClick={() => router.back()}>
                    <ArrowLeft className="h-4 w-4" />
                </Button>
                <div className="flex items-center gap-4">
                     <Avatar className="w-20 h-20 border-2 border-primary">
                        <AvatarImage src={store.sellerPhotoUrl} alt={store.sellerName} />
                        <AvatarFallback>{store.sellerName.charAt(0)}</AvatarFallback>
                    </Avatar>
                    <div>
                        <h1 className="text-3xl font-headline font-bold text-primary">{store.sellerName}</h1>
                        <p className="text-lg text-muted-foreground">{store.name}</p>
                    </div>
                </div>
            </header>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <Card className="md:col-span-1">
                    <CardHeader>
                        <CardTitle>Seller Details</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4 text-sm">
                        <div className="flex items-start gap-3">
                            <Mail className="h-4 w-4 text-muted-foreground mt-1" />
                            <div>
                                <p className="font-semibold">Email</p>
                                <p>{store.sellerEmail}</p>
                            </div>
                        </div>
                         <div className="flex items-start gap-3">
                            <Phone className="h-4 w-4 text-muted-foreground mt-1" />
                             <div>
                                <p className="font-semibold">Phone</p>
                                <p>{store.sellerPhone}</p>
                            </div>
                        </div>
                        <div className="flex items-start gap-3">
                            <Home className="h-4 w-4 text-muted-foreground mt-1" />
                            <div>
                                <p className="font-semibold">Address</p>
                                <p>{store.address}</p>
                                {store.landmark && <p className='text-muted-foreground'>Landmark: {store.landmark}</p>}
                                <p>{store.city}, {store.pincode}</p>
                            </div>
                        </div>
                    </CardContent>
                </Card>
                 <Card>
                    <CardHeader>
                        <CardTitle>Total Revenue</CardTitle>
                    </CardHeader>
                    <CardContent>
                        <p className="text-3xl font-bold">₹{totalRevenue.toLocaleString()}</p>
                        <p className="text-sm text-muted-foreground">from {sellerOrders.length} orders</p>
                    </CardContent>
                </Card>
                 <Card>
                    <CardHeader>
                        <CardTitle>Total Products</CardTitle>
                    </CardHeader>
                    <CardContent>
                        <p className="text-3xl font-bold">{sellerProducts.length}</p>
                         <p className="text-sm text-muted-foreground">listed in store</p>
                    </CardContent>
                </Card>
            </div>

             <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <Card>
                    <CardHeader>
                        <CardTitle>Seller Status & Actions</CardTitle>
                    </CardHeader>
                    <CardContent className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                    <div className="flex items-center gap-2">
                        <p>Current Status:</p>
                        <Badge variant={store.status === 'blocked' ? 'destructive' : 'default'} className="text-base">
                            {store.status === 'blocked' ? <ShieldAlert className="mr-2 h-4 w-4" /> : <ShieldCheck className="mr-2 h-4 w-4" />}
                            {store.status}
                        </Badge>
                    </div>
                    <div className="flex gap-2">
                        {store.status === 'active' ? (
                            <Button variant="destructive" onClick={handleBlock}>
                                <ShieldOff className="mr-2 h-4 w-4" /> Block Seller
                            </Button>
                        ) : (
                            <Button onClick={handleUnblock}>
                                <ShieldCheck className="mr-2 h-4 w-4" /> Unblock Seller
                            </Button>
                        )}
                    </div>
                    </CardContent>
                </Card>
                <Card>
                     <CardHeader>
                        <CardTitle>Registration Date</CardTitle>
                    </CardHeader>
                    <CardContent className="flex items-center gap-2 text-sm">
                        <CalendarIcon className="h-5 w-5 text-muted-foreground" />
                        <div>
                            <p className='font-semibold'>{format(registrationDate, 'PPpp')}</p>
                            <p className='text-muted-foreground'>{formatDistanceToNow(registrationDate, { addSuffix: true })}</p>
                        </div>
                    </CardContent>
                </Card>
            </div>

            <Card>
                <CardHeader>
                    <CardTitle>Products</CardTitle>
                    <CardDescription>All products listed by {store.sellerName}.</CardDescription>
                </CardHeader>
                <CardContent>
                    <Table>
                        <TableHeader>
                            <TableRow>
                                <TableHead>Product</TableHead>
                                <TableHead>Category</TableHead>
                                <TableHead className="text-right">Price</TableHead>
                            </TableRow>
                        </TableHeader>
                        <TableBody>
                            {sellerProducts.map(product => (
                                <TableRow key={product.id}>
                                    <TableCell>
                                        <div className="flex items-center gap-3">
                                            <Image src={product.imageUrls[0]} alt={product.name} width={40} height={40} className="rounded-md object-cover" />
                                            <span className="font-medium">{product.name}</span>
                                        </div>
                                    </TableCell>
                                    <TableCell>{product.category}</TableCell>
                                    <TableCell className="text-right">₹{product.price.toLocaleString()}</TableCell>
                                </TableRow>
                            ))}
                        </TableBody>
                    </Table>
                </CardContent>
            </Card>
            
            <Card>
                <CardHeader>
                    <CardTitle>Orders</CardTitle>
                    <CardDescription>All orders containing products from this seller.</CardDescription>
                </CardHeader>
                <CardContent>
                     <Table>
                        <TableHeader>
                            <TableRow>
                                <TableHead>Order ID</TableHead>
                                <TableHead>Customer</TableHead>
                                <TableHead>Status</TableHead>
                                <TableHead>Amount</TableHead>
                                <TableHead className="text-right">Actions</TableHead>
                            </TableRow>
                        </TableHeader>
                        <TableBody>
                            {sellerOrders.map((order: Order) => (
                                <TableRow key={order.id}>
                                    <TableCell className="font-medium">{order.id}</TableCell>
                                    <TableCell>{order.buyerName}</TableCell>
                                    <TableCell>
                                        <Badge variant={statusVariantMap[order.status] || 'default'}>
                                            {order.status}
                                        </Badge>
                                    </TableCell>
                                    <TableCell>₹{order.total.toLocaleString()}</TableCell>
                                    <TableCell className="text-right space-x-2">
                                         <Dialog>
                                            <DialogTrigger asChild>
                                                <Button variant="outline" size="sm"><FileText className="mr-2 h-4 w-4" /> View Bill</Button>
                                            </DialogTrigger>
                                            <DialogContent className="max-w-2xl">
                                                <OrderBill order={order} store={store} />
                                            </DialogContent>
                                        </Dialog>
                                        <Dialog>
                                            <DialogTrigger asChild>
                                                <Button variant="outline" size="sm"><Send className="mr-2 h-4 w-4" /> View Label</Button>
                                            </DialogTrigger>
                                            <DialogContent className="max-w-md">
                                                <ShippingLabel order={order} store={store} />
                                            </DialogContent>
                                        </Dialog>
                                    </TableCell>
                                </TableRow>
                            ))}
                        </TableBody>
                    </Table>
                </CardContent>
            </Card>

        </div>
    );
}
