
'use client';

import { useState, useMemo } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Users, ShoppingBag, LineChart, DollarSign, ShieldAlert } from 'lucide-react';
import { useApp } from '@/hooks/use-app';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';
import Image from 'next/image';
import type { Order } from '@/lib/types';
import { useRouter } from 'next/navigation';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';


export default function AdminPage() {
  const [password, setPassword] = useState('');
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const router = useRouter();
  
  const { stores, products, orders } = useApp();

  const sortedStores = useMemo(() => {
    return [...stores].sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }, [stores]);


  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (password === '786786') {
      setIsAuthenticated(true);
    } else {
      alert('Incorrect password');
    }
  };

  if (!isAuthenticated) {
    return (
      <div className="flex items-center justify-center min-h-[calc(100vh-200px)]">
        <Card className="w-full max-w-sm">
          <CardHeader>
            <CardTitle className="text-2xl text-center">Admin Login</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleLogin} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="password">Password</Label>
                <Input
                  id="password"
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                />
              </div>
              <Button type="submit" className="w-full">
                Enter
              </Button>
            </form>
          </CardContent>
        </Card>
      </div>
    );
  }
  
  const totalSellers = stores.length;
  const totalProducts = products.length;
  const totalOrders = orders.length;
  const totalRevenue = orders.reduce((sum, order) => sum + order.total, 0);
  const commission = totalRevenue * 0.05;
  const buyers = [...new Set(orders.map((o: Order) => o.buyerName))];
  const totalBuyers = buyers.length;

  return (
    <div className="max-w-7xl mx-auto space-y-8">
        <header className="text-center">
            <h1 className="text-4xl md:text-5xl font-headline text-primary font-bold">Admin Dashboard</h1>
            <p className="text-lg text-muted-foreground mt-2">Welcome, Admin!</p>
        </header>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">Total Users</CardTitle>
                    <Users className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                    <div className="text-2xl font-bold">{totalBuyers + totalSellers}</div>
                    <p className="text-xs text-muted-foreground">{totalBuyers} Buyers, {totalSellers} Sellers</p>
                </CardContent>
            </Card>
            <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">Total Products</CardTitle>
                    <ShoppingBag className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                    <div className="text-2xl font-bold">{totalProducts}</div>
                    <p className="text-xs text-muted-foreground">Listed across all stores</p>
                </CardContent>
            </Card>
             <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">Total Revenue</CardTitle>
                    <DollarSign className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                    <div className="text-2xl font-bold">₹{totalRevenue.toLocaleString()}</div>
                    <p className="text-xs text-muted-foreground">Total value of all orders</p>
                </CardContent>
            </Card>
             <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">Commission Earned</CardTitle>
                    <LineChart className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                    <div className="text-2xl font-bold">₹{commission.toLocaleString(undefined, {minimumFractionDigits: 2})}</div>
                    <p className="text-xs text-muted-foreground">5% of total revenue</p>
                </CardContent>
            </Card>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <Card>
                <CardHeader>
                    <CardTitle>Sellers</CardTitle>
                    <CardDescription>All registered sellers on the platform, newest first.</CardDescription>
                </CardHeader>
                <CardContent>
                    <Table>
                        <TableHeader>
                            <TableRow>
                                <TableHead>Seller</TableHead>
                                <TableHead>Store</TableHead>
                                <TableHead>City</TableHead>
                                <TableHead>Status</TableHead>
                            </TableRow>
                        </TableHeader>
                        <TableBody>
                            {sortedStores.map(store => (
                                <TableRow key={store.id} onClick={() => router.push(`/admin/seller/${store.id}`)} className={cn("cursor-pointer", store.status === 'blocked' && 'bg-destructive/10 hover:bg-destructive/20')}>
                                    <TableCell>
                                        <div className="flex items-center gap-2">
                                            <Avatar className="h-8 w-8">
                                                <AvatarImage src={store.sellerPhotoUrl} />
                                                <AvatarFallback>{store.sellerName.charAt(0)}</AvatarFallback>
                                            </Avatar>
                                            <span>{store.sellerName}</span>
                                        </div>
                                    </TableCell>
                                    <TableCell>{store.name}</TableCell>
                                    <TableCell>{store.city}</TableCell>
                                    <TableCell>
                                        <Badge variant={store.status === 'blocked' ? 'destructive' : 'default'}>
                                            {store.status}
                                        </Badge>
                                    </TableCell>
                                </TableRow>
                            ))}
                        </TableBody>
                    </Table>
                </CardContent>
            </Card>

            <Card>
                <CardHeader>
                    <CardTitle>Buyers</CardTitle>
                    <CardDescription>All users who have placed an order.</CardDescription>
                </CardHeader>
                <CardContent>
                    <Table>
                        <TableHeader>
                            <TableRow>
                                <TableHead>Buyer</TableHead>
                                <TableHead>Orders</TableHead>
                            </TableRow>
                        </TableHeader>
                        <TableBody>
                            {buyers.map(buyerName => (
                                <TableRow key={buyerName}>
                                    <TableCell>{buyerName}</TableCell>
                                    <TableCell>{orders.filter((o: Order) => o.buyerName === buyerName).length}</TableCell>
                                </TableRow>
                            ))}
                        </TableBody>
                    </Table>
                </CardContent>
            </Card>
        </div>

        <Card>
            <CardHeader>
                <CardTitle>All Products</CardTitle>
                <CardDescription>A list of all products currently on the platform.</CardDescription>
            </CardHeader>
            <CardContent>
                 <Table>
                    <TableHeader>
                        <TableRow>
                            <TableHead>Product</TableHead>
                            <TableHead>Store</TableHead>
                            <TableHead>Price</TableHead>
                        </TableRow>
                    </TableHeader>
                    <TableBody>
                        {products.map(product => {
                            const store = stores.find(s => s.id === product.storeId);
                            return (
                                <TableRow key={product.id} className={cn(store?.status === 'blocked' && 'opacity-50')}>
                                    <TableCell>
                                        <div className="flex items-center gap-2 font-medium">
                                            <Image src={product.imageUrls[0]} alt={product.name} width={40} height={40} className="rounded-md object-cover" />
                                            <span>{product.name}</span>
                                        </div>
                                    </TableCell>
                                    <TableCell>{store?.name || 'N/A'}</TableCell>
                                    <TableCell>₹{product.price.toLocaleString()}</TableCell>
                                </TableRow>
                            )
                        })}
                    </TableBody>
                </Table>
            </CardContent>
        </Card>
    </div>
  );
}
