'use server';

import { generateProductDescription } from '@/ai/flows/generate-product-description';
import { generateProductDetails } from '@/ai/flows/generate-product-details';
import { textToSpeech } from '@/ai/flows/text-to-speech';

export async function generateDescriptionAction(productPhotoDataUri: string): Promise<{
  success: boolean;
  description?: string;
  error?: string;
}> {
  try {
    const result = await generateProductDescription({ productPhotoDataUri });
    return { success: true, description: result.description };
  } catch (e) {
    console.error(e);
    const error = e instanceof Error ? e.message : 'An unknown error occurred.';
    return { success: false, error };
  }
}

export async function generateDetailsAction(productPhotoDataUri: string): Promise<{
  success: boolean;
  details?: any;
  error?: string;
}> {
  try {
    const result = await generateProductDetails({ productPhotoDataUri });
    return { success: true, details: result };
  } catch (e) {
    console.error(e);
    const error = e instanceof Error ? e.message : 'An unknown error occurred.';
    return { success: false, error };
  }
}


export async function textToSpeechAction(text: string): Promise<{
  success: boolean;
  audioDataUri?: string;
  error?: string;
}> {
  try {
    const result = await textToSpeech(text);
    return { success: true, audioDataUri: result.audioDataUri };
  } catch (e) {
    console.error(e);
    const error = e instanceof Error ? e.message : 'An unknown error occurred.';
    return { success: false, error };
  }
}
