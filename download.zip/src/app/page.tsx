
'use client';
import { HomeClient } from "@/components/home-client";
import { useApp } from "@/hooks/use-app";

export default function Home() {
  const { products, categories } = useApp();
  return <HomeClient products={products} categories={categories} />;
}
