

'use client';

import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { AddProductForm } from '@/components/add-product-form';
import type { Product, Store, Category, Order, City, UserAddress } from '@/lib/types';
import Image from 'next/image';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Info, ShoppingBag, DollarSign, Clock, CheckCircle, Settings, CreditCard, Package, User, PlusCircle, Edit, Trash2, Check, X, MessageSquare, LocateFixed, Loader2, FileText, Send, ChevronDown } from 'lucide-react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger, DialogClose } from "@/components/ui/dialog";
import { AudioGuide } from '@/components/audio-guide';
import { useApp } from '@/hooks/use-app';
import { useToast } from '@/hooks/use-toast';
import { useLocation } from '@/hooks/use-location';
import { useAuth } from '@/hooks/use-auth';
import { OrderBill } from '@/components/order-bill';
import { ShippingLabel } from '@/components/shipping-label';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";


function AddCityModal({ onCityAdd }: { onCityAdd: (city: Omit<City, 'lat' | 'lng'>) => void }) {
    const [city, setCity] = useState('');
    const [pincode, setPincode] = useState('');

    const handleSubmit = () => {
        if (city.trim() && pincode.trim()) {
            onCityAdd({ name: city.trim(), pincode: pincode.trim() });
            setCity('');
            setPincode('');
        }
    }

    return (
        <Dialog>
            <DialogTrigger asChild>
                <Button type="button" variant="outline" size="sm">
                    <PlusCircle className="mr-2 h-4 w-4" />
                    New City
                </Button>
            </DialogTrigger>
            <DialogContent>
                <DialogHeader>
                    <DialogTitle>Add a New City</DialogTitle>
                    <DialogDescription>
                        If your city isn't in the list, you can add it here with its primary pincode.
                    </DialogDescription>
                </DialogHeader>
                <div className="space-y-4">
                    <div>
                        <Label htmlFor="city-name">City Name</Label>
                        <Input id="city-name" value={city} onChange={e => setCity(e.target.value)} />
                    </div>
                     <div>
                        <Label htmlFor="city-pincode">Pincode</Label>
                        <Input id="city-pincode" value={pincode} onChange={e => setPincode(e.target.value)} />
                    </div>
                    <DialogClose asChild>
                        <Button onClick={handleSubmit} disabled={!city.trim() || !pincode.trim()}>Add City</Button>
                    </DialogClose>
                </div>
            </DialogContent>
        </Dialog>
    )
}

function CreateStoreForm({ onStoreCreate, cities, onCityAdd, address: currentAddress, detectLocation, isDetecting }: { onStoreCreate: (store: Omit<Store, 'id' | 'createdAt'>) => void, cities: City[], onCityAdd: (city: City) => void, address: UserAddress | null, detectLocation: () => Promise<any>, isDetecting: boolean }) {
    const { user } = useAuth();
    const [storeName, setStoreName] = useState('');
    const [storeDetails, setStoreDetails] = useState('');
    const [address, setAddress] = useState('');
    const [landmark, setLandmark] = useState('');
    const [pincode, setPincode] = useState('');
    const [city, setCity] = useState(cities[0]?.name || '');
    const [sellerName, setSellerName] = useState(user?.displayName || '');
    const [sellerEmail, setSellerEmail] = useState(user?.email || '');
    const [sellerPhone, setSellerPhone] = useState('');
    const [sellerPhotoUrl, setSellerPhotoUrl] = useState(user?.photoURL || '');
    const [paymentMethod, setPaymentMethod] = useState<'upi' | 'bank'>('upi');
    const [upiId, setUpiId] = useState('');
    const [bankAccountName, setBankAccountName] = useState('');
    const [bankAccountNumber, setBankAccountNumber] = useState('');
    const [bankIfscCode, setBankIfscCode] = useState('');
    
    useEffect(() => {
        const selectedCityData = cities.find(c => c.name === city);
        if (selectedCityData) {
            setPincode(selectedCityData.pincode);
        }
    }, [city, cities]);

    useEffect(() => {
        if(currentAddress) {
            setAddress(currentAddress.street);
            setCity(currentAddress.city);
            setPincode(currentAddress.pincode);
        }
    }, [currentAddress])


    const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (file) {
            const reader = new FileReader();
            reader.onloadend = () => {
                setSellerPhotoUrl(reader.result as string);
            };
            reader.readAsDataURL(file);
        }
    };
    
    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        const isUpiValid = paymentMethod === 'upi' && upiId;
        const isBankValid = paymentMethod === 'bank' && bankAccountName && bankAccountNumber && bankIfscCode;
        const selectedCityData = cities.find(c => c.name === city && c.pincode === pincode);

        if (user && user.email && storeName && storeDetails && address && pincode && city && sellerName && sellerEmail && sellerPhone && sellerPhotoUrl && (isUpiValid || isBankValid)) {
            onStoreCreate({
                name: storeName,
                details: storeDetails,
                address,
                landmark,
                city,
                pincode: pincode,
                lat: selectedCityData?.lat,
                lng: selectedCityData?.lng,
                sellerName,
                sellerEmail,
                sellerPhone,
                sellerPhotoUrl,
                paymentMethod,
                upiId: paymentMethod === 'upi' ? upiId : undefined,
                bankAccountName: paymentMethod === 'bank' ? bankAccountName : undefined,
                bankAccountNumber: paymentMethod === 'bank' ? bankAccountNumber : undefined,
                bankIfscCode: paymentMethod === 'bank' ? bankIfscCode : undefined,
                status: 'active',
                userEmail: user.email,
            });
        } else {
            alert('Please fill all required fields correctly.');
        }
    };

    const storeCreationAudioGuideText = `
        स्टोर बनाने के लिए कृपया यह जानकारी भरें.
        पहले, अपनी एक साफ़ तस्वीर अपलोड करें.
        फिर, अपना पूरा नाम दर्ज करें.
        इसके बाद, अपनी ईमेल आईडी दर्ज करें.
        फिर अपना कांटेक्ट नंबर डालें
        अब, अपनी दुकान का नाम लिखें.
        फिर, अपनी दुकान के बारे में कुछ जानकारी दें.
        अपना पूरा पता, शहर और पिनकोड डालें.
        अंत में, भुगतान प्राप्त करने के लिए अपनी UPI ID या बैंक खाते का विवरण दर्ज करें.
    `;

    const handleCitySelect = (value: string) => {
        const [selectedCityName, selectedPincode] = value.split('|');
        const selectedCityData = cities.find(c => c.name === selectedCityName && c.pincode === selectedPincode);
        if (selectedCityData) {
            setCity(selectedCityData.name);
            setPincode(selectedCityData.pincode);
        }
    }

    return (
        <Card className="w-full max-w-lg mx-auto">
            <CardHeader className="text-center">
                <CardTitle className="text-3xl font-headline text-primary">Create Your Store</CardTitle>
                <CardDescription>Start selling your products on Rrk Apna Bajar today!</CardDescription>
            </CardHeader>
            <CardContent>
                <Alert className="mb-6 bg-blue-50 border-blue-200">
                  <Info className="h-4 w-4 text-blue-700" />
                  <AlertTitle className="font-semibold text-blue-800">Platform Fees</AlertTitle>
                  <AlertDescription className="text-blue-700">
                    5% Commission + 2% Maintenance Charge will be applied to all sales.
                  </AlertDescription>
                </Alert>
                <form onSubmit={handleSubmit} className="space-y-6">
                    <div className="flex justify-end">
                        <AudioGuide text={storeCreationAudioGuideText} buttonText="Audio Guide" />
                    </div>
                    {/* Seller Info */}
                    <div className="space-y-4 p-4 border rounded-lg">
                        <h3 className="text-lg font-semibold text-primary">Your Details</h3>
                        <div className="flex items-center gap-4">
                            <Avatar className="w-20 h-20">
                                <AvatarImage src={sellerPhotoUrl} />
                                <AvatarFallback><User /></AvatarFallback>
                            </Avatar>
                             <div className="space-y-2 flex-grow">
                                <Label htmlFor="seller-photo">Your Photo</Label>
                                <Input 
                                    id="seller-photo" 
                                    type="file" 
                                    accept="image/*" 
                                    onChange={handlePhotoUpload} 
                                    required 
                                />
                            </div>
                        </div>
                        <div className="space-y-2">
                            <Label htmlFor="seller-name">Your Full Name</Label>
                            <Input id="seller-name" value={sellerName} onChange={e => setSellerName(e.target.value)} required />
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                            <div className="space-y-2">
                                <Label htmlFor="seller-email">Your Email ID</Label>
                                <Input id="seller-email" type="email" value={sellerEmail} onChange={e => setSellerEmail(e.target.value)} required disabled />
                            </div>
                             <div className="space-y-2">
                                <Label htmlFor="seller-phone">Contact Number</Label>
                                <Input id="seller-phone" type="tel" value={sellerPhone} onChange={e => setSellerPhone(e.target.value)} required />
                            </div>
                        </div>
                    </div>
                    {/* Store Info */}
                     <div className="space-y-4 p-4 border rounded-lg">
                         <h3 className="text-lg font-semibold text-primary">Store Details</h3>
                        <div className="space-y-2">
                           <Label htmlFor="store-name">Store Name</Label>
                            <Input 
                                id="store-name" 
                                placeholder="e.g., Rohan's Handicrafts" 
                                value={storeName}
                                onChange={(e) => setStoreName(e.target.value)}
                                required 
                            />
                        </div>
                        <div className="space-y-2">
                            <Label htmlFor="store-details">Store Description</Label>
                            <Textarea 
                                id="store-details" 
                                placeholder="Describe what your store sells..." 
                                value={storeDetails}
                                onChange={(e) => setStoreDetails(e.target.value)}
                                required 
                            />
                        </div>

                        <div className="flex justify-end">
                            <Button type="button" variant="outline" size="sm" onClick={detectLocation} disabled={isDetecting}>
                                {isDetecting ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <LocateFixed className="mr-2 h-4 w-4" />}
                                Detect Current Address
                            </Button>
                        </div>

                        <div className="space-y-2">
                            <Label htmlFor="address">Full Address</Label>
                            <Input id="address" placeholder="e.g., 123, Main Street" value={address} onChange={e => setAddress(e.target.value)} required />
                        </div>
                        <div className="space-y-2">
                            <Label htmlFor="landmark">Landmark (Optional)</Label>
                            <Input id="landmark" placeholder="e.g., Near City Mall" value={landmark} onChange={e => setLandmark(e.target.value)} />
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                            <div className="space-y-2">
                                <div className="flex justify-between items-center">
                                    <Label htmlFor="city">City / Area</Label>
                                    <AddCityModal onCityAdd={onCityAdd} />
                                </div>
                                <Select onValueChange={handleCitySelect} value={`${city}|${pincode}`}>
                                <SelectTrigger>
                                        <SelectValue placeholder="Select a city" />
                                </SelectTrigger>
                                    <SelectContent>
                                        {cities.map(c => (
                                            <SelectItem key={`${c.name}-${c.pincode}`} value={`${c.name}|${c.pincode}`}>{c.name} - {c.pincode}</SelectItem>
                                        ))}
                                    </SelectContent>
                                </Select>
                            </div>
                            <div className="space-y-2">
                                <Label htmlFor="pincode">Pincode</Label>
                                <Input 
                                    id="pincode" 
                                    placeholder="e.g., 110001" 
                                    value={pincode}
                                    onChange={(e) => setPincode(e.target.value)}
                                    required 
                                />
                            </div>
                        </div>
                        <p className="text-xs text-muted-foreground pt-1">Your city determines who sees your products.</p>
                     </div>
                    {/* Payment Info */}
                    <div className="space-y-4 p-4 border rounded-lg">
                        <h3 className="text-lg font-semibold text-primary">Payment Details</h3>
                        <p className="text-sm text-muted-foreground">This is where you'll receive payments for your sales.</p>
                        <RadioGroup onValueChange={(v) => setPaymentMethod(v as 'upi' | 'bank')} defaultValue={paymentMethod} className="flex gap-4">
                            <div className="flex items-center space-x-2">
                                <RadioGroupItem value="upi" id="upi" />
                                <Label htmlFor="upi">UPI</Label>
                            </div>
                             <div className="flex items-center space-x-2">
                                <RadioGroupItem value="bank" id="bank" />
                                <Label htmlFor="bank">Bank Transfer</Label>
                            </div>
                        </RadioGroup>
                        
                        {paymentMethod === 'upi' && (
                             <div className="space-y-2">
                                <Label htmlFor="upi-id">Your UPI ID</Label>
                                <Input 
                                    id="upi-id" 
                                    placeholder="your-id@bank" 
                                    value={upiId}
                                    onChange={(e) => setUpiId(e.target.value)}
                                    required={paymentMethod === 'upi'}
                                />
                            </div>
                        )}
                        {paymentMethod === 'bank' && (
                            <div className="space-y-4">
                                <div className="space-y-2">
                                    <Label htmlFor="bank-acc-name">Account Holder Name</Label>
                                    <Input value={bankAccountName || ''} onChange={e => setBankAccountName(e.target.value)} required={paymentMethod === 'bank'} />
                                </div>
                                <div className="space-y-2">
                                    <Label htmlFor="bank-acc-number">Account Number</Label>
                                    <Input value={bankAccountNumber || ''} onChange={e => setBankAccountNumber(e.target.value)} required={paymentMethod === 'bank'} />
                                </div>
                                <div className="space-y-2">
                                    <Label htmlFor="bank-ifsc">IFSC Code</Label>
                                    <Input value={bankIfscCode || ''} onChange={e => setBankIfscCode(e.target.value)} required={paymentMethod === 'bank'} />
                                </div>
                            </div>
                        )}

                    </div>

                    <Button type="submit" className="w-full bg-accent hover:bg-accent/90" size="lg">Create My Store</Button>
                </form>
            </CardContent>
        </Card>
    );
}

const statusVariantMap: { [key: string]: "default" | "secondary" | "destructive" } = {
    'Delivered': 'default',
    'Pending': 'secondary',
    'Confirmed': 'default',
    'Cancelled': 'destructive',
};

function StoreSettings({ store }: { store: Store }) {
    return (
        <Dialog>
            <DialogTrigger asChild>
                <Button variant="outline" size="icon">
                    <Settings className="h-5 w-5" />
                </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl">
                <DialogHeader>
                    <DialogTitle>Store Settings</DialogTitle>
                    <DialogDescription>
                        Manage your store profile and payment details here.
                    </DialogDescription>
                </DialogHeader>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8 py-4">
                    <Card>
                        <CardHeader>
                            <CardTitle>Store Profile</CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-4">
                            <div className="space-y-2">
                                <Label htmlFor="store-name">Store Name</Label>
                                <Input id="store-name" defaultValue={store.name} />
                            </div>
                            <div className="space-y-2">
                                <Label htmlFor="store-details">Store Details</Label>
                                <Textarea id="store-details" defaultValue={store.details} />
                            </div>
                             <div className="space-y-2">
                                <Label htmlFor="store-location">City</Label>
                                <Input id="store-location" defaultValue={store.city} disabled />
                            </div>
                            <Button className="bg-accent hover:bg-accent/90">Save Profile</Button>
                        </CardContent>
                    </Card>
                     <Card>
                        <CardHeader>
                            <CardTitle>Payment Settings</CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-4">
                             {store.upiId && (
                                <div className="space-y-2">
                                    <Label htmlFor="upi-id">UPI ID</Label>
                                    <Input id="upi-id" placeholder="your-name@bank" defaultValue={store.upiId} />
                                </div>
                            )}
                            {store.bankAccountNumber && (
                                <div className="space-y-2">
                                    <Label>Bank Account</Label>
                                    <div className='p-3 border rounded-md bg-muted text-sm'>
                                        <p><strong>Holder:</strong> {store.bankAccountName}</p>
                                        <p><strong>Account No:</strong> {store.bankAccountNumber}</p>
                                        <p><strong>IFSC:</strong> {store.bankIfscCode}</p>
                                    </div>
                                </div>
                            )}
                            <Button className="bg-accent hover:bg-accent/90">Update Payments</Button>
                        </CardContent>
                    </Card>
                </div>
            </DialogContent>
        </Dialog>
    )
}

export default function SellPage() {
  const { products, addProduct, stores, addStore, categories, addCategory, cities, addCity, orders, updateOrderStatus } = useApp();
  const { address, detectLocation, isDetecting } = useLocation();
  const { user, loading } = useAuth();
  const [myStore, setMyStore] = useState<Store | null>(null);
  const [isClient, setIsClient] = useState(false);
  const [isAddProductOpen, setIsAddProductOpen] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    setIsClient(true);
    if (user && stores.length > 0) {
        const storeForUser = stores.find(s => s.userEmail === user.email);
        setMyStore(storeForUser || null);
    } else {
        setMyStore(null);
    }
  }, [stores, user]);

  const handleStoreCreate = (newStoreData: Omit<Store, 'id' | 'createdAt'>) => {
    addStore(newStoreData);
    toast({
        title: "Store Created!",
        description: "Your store has been successfully created. You can now add products.",
    });
  };
  
  const handleAddProduct = (newProduct: Omit<Product, 'id' | 'storeId' | 'location' | 'status' | 'rating' | 'reviews'>) => {
    if (!myStore) return;

    const highestId = products.length > 0 ? Math.max(...products.map(p => p.id)) : 0;
    const productToAdd: Product = {
        ...newProduct,
        id: highestId + 1,
        storeId: myStore.id,
        location: myStore.city,
        status: 'active',
        rating: Math.floor(Math.random() * (5 - 3 + 1)) + 3,
        reviews: Math.floor(Math.random() * 100),
    };
    addProduct(productToAdd);
    setIsAddProductOpen(false);
  };
  
  const myProducts = myStore ? products.filter(p => p.storeId === myStore.id) : [];
  
  const myProductIds = myProducts.map(p => p.id);

  const myOrders = orders.filter(order => 
      order.items.some(item => {
          const product = products.find(p => p.name === item.name);
          return product ? myProductIds.includes(product.id) : false;
      })
  ).sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

  const handleOrderStatusChange = (orderId: string, status: Order['status']) => {
    updateOrderStatus(orderId, status);
    toast({
      title: `Order ${status}`,
      description: `Order ${orderId} has been marked as ${status}.`,
    });
  };

  const handleWhatsApp = (order: Order) => {
    const items = order.items.map(item => `${item.name} (Qty: ${item.quantity})`).join(', ');
    const message = `Order details for ${order.id}:\nItems: ${items}\nTotal: ₹${order.total}\nStatus: ${order.status}\n\nShipping to:\n${order.buyerName}\n${order.shippingAddress.street}, ${order.shippingAddress.city}, ${order.shippingAddress.pincode}`;
    const whatsappUrl = `https://wa.me/?text=${encodeURIComponent(message)}`;
    window.open(whatsappUrl, '_blank');
  };

  if (!isClient || loading) {
      return (
         <div className="flex justify-center items-center min-h-[calc(100vh-200px)]">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      );
  }

  if (!user) {
    // This can happen briefly during redirects, or if the user is not logged in.
    // The AuthProvider should handle the redirect, but this is a safe fallback.
    return (
        <div className="flex justify-center items-center min-h-[calc(100vh-200px)]">
            <p>Please log in to manage your store.</p>
        </div>
    );
  }

  if (!myStore) {
    return (
       <div className="max-w-5xl mx-auto py-8">
            <CreateStoreForm 
                onStoreCreate={handleStoreCreate} 
                cities={cities} 
                onCityAdd={addCity as any} 
                address={address}
                detectLocation={detectLocation}
                isDetecting={isDetecting}
            />
       </div>
    );
  }
  
  const totalRevenue = myOrders.reduce((sum, order) => order.status !== 'Cancelled' ? sum + order.total : sum, 0);
  const pendingOrders = myOrders.filter(o => o.status === 'Pending').length;

  return (
    <div className="max-w-7xl mx-auto space-y-6">
        <header className="flex justify-between items-center">
            <div className="flex items-center gap-4">
                <Avatar className="w-16 h-16 border-2 border-primary">
                    <AvatarImage src={myStore.sellerPhotoUrl} alt={myStore.sellerName} />
                    <AvatarFallback>{myStore.sellerName.charAt(0)}</AvatarFallback>
                </Avatar>
                <div>
                     <h1 className="text-2xl md:text-3xl font-headline text-primary font-bold">{myStore.name}</h1>
                     <p className="text-md text-muted-foreground">Managed by <span className="font-semibold">{myStore.sellerName}</span></p>
                </div>
            </div>
            <StoreSettings store={myStore} />
        </header>
        
        {/* Dashboard Cards */}
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">Total Revenue</CardTitle>
                    <DollarSign className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                    <div className="text-2xl font-bold">₹{totalRevenue.toLocaleString()}</div>
                    <p className="text-xs text-muted-foreground">From all successful orders</p>
                </CardContent>
            </Card>
            <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">Total Orders</CardTitle>
                    <ShoppingBag className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                    <div className="text-2xl font-bold">+{myOrders.length}</div>
                    <p className="text-xs text-muted-foreground">Total orders received</p>
                </CardContent>
            </Card>
            <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">Pending Orders</CardTitle>
                    <Clock className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                    <div className="text-2xl font-bold">{pendingOrders}</div>
                    <p className="text-xs text-muted-foreground">Awaiting your confirmation</p>
                </CardContent>
            </Card>
            <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">Listed Products</CardTitle>
                    <Package className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                    <div className="text-2xl font-bold">{myProducts.length}</div>
                    <p className="text-xs text-muted-foreground">Currently in your store</p>
                </CardContent>
            </Card>
        </div>

        {/* Add Product Button */}
        <Dialog open={isAddProductOpen} onOpenChange={setIsAddProductOpen}>
            <DialogTrigger asChild>
                <Button size="lg" className="w-full">
                    <PlusCircle className="mr-2 h-5 w-5" />
                    Add New Product
                </Button>
            </DialogTrigger>
            <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
                <DialogHeader>
                    <DialogTitle>Add a New Product</DialogTitle>
                    <DialogDescription>
                        Fill in the details below to list a new product in your store.
                    </DialogDescription>
                </DialogHeader>
                <AddProductForm 
                    onProductAdd={handleAddProduct}
                    categories={categories}
                    onCategoryAdd={addCategory}
                />
            </DialogContent>
        </Dialog>

        {/* Accordion for Orders and Products */}
        <Accordion type="single" collapsible className="w-full space-y-4">
            <AccordionItem value="orders" className="border rounded-lg bg-card/50">
                <AccordionTrigger className="p-4 text-lg font-headline">
                    <div className='flex items-center gap-2'>
                        <ShoppingBag className='h-5 w-5' />
                        Recent Orders
                    </div>
                </AccordionTrigger>
                <AccordionContent className="px-4 pb-4">
                     <Table>
                        <TableHeader>
                            <TableRow>
                                <TableHead>Order ID</TableHead>
                                <TableHead>Customer</TableHead>
                                <TableHead>Status</TableHead>
                                <TableHead>Amount</TableHead>
                                <TableHead className="text-right">Actions</TableHead>
                            </TableRow>
                        </TableHeader>
                        <TableBody>
                            {myOrders.map((order) => (
                                <TableRow key={order.id}>
                                    <TableCell className="font-medium">{order.id}</TableCell>
                                    <TableCell>{order.buyerName}</TableCell>
                                    <TableCell>
                                        <Badge variant={statusVariantMap[order.status] || 'default'}>
                                            {order.status}
                                        </Badge>
                                    </TableCell>
                                    <TableCell>₹{order.total.toLocaleString()}</TableCell>
                                        <TableCell className="text-right space-x-1">
                                        {order.status === 'Pending' && (
                                            <>
                                                <Button variant="ghost" size="icon" onClick={() => handleOrderStatusChange(order.id, 'Confirmed')} title="Confirm Order">
                                                    <Check className="h-4 w-4 text-green-600" />
                                                </Button>
                                                <Button variant="ghost" size="icon" onClick={() => handleOrderStatusChange(order.id, 'Cancelled')} title="Cancel Order">
                                                    <X className="h-4 w-4 text-red-600" />
                                                </Button>
                                            </>
                                        )}
                                        <Dialog>
                                            <DialogTrigger asChild>
                                                <Button variant="ghost" size="icon" title="View Bill">
                                                    <FileText className="h-4 w-4 text-blue-600" />
                                                </Button>
                                            </DialogTrigger>
                                            <DialogContent className="max-w-2xl">
                                                <OrderBill order={order} store={myStore} />
                                            </DialogContent>
                                        </Dialog>
                                        <Dialog>
                                            <DialogTrigger asChild>
                                                <Button variant="ghost" size="icon" title="View Shipping Label">
                                                    <Send className="h-4 w-4 text-purple-600" />
                                                </Button>
                                            </DialogTrigger>
                                            <DialogContent className="max-w-md">
                                                <ShippingLabel order={order} store={myStore} />
                                            </DialogContent>
                                        </Dialog>
                                        <Button variant="ghost" size="icon" onClick={() => handleWhatsApp(order)} title="Send on WhatsApp">
                                            <MessageSquare className="h-4 w-4 text-green-500" />
                                        </Button>
                                    </TableCell>
                                </TableRow>
                            ))}
                        </TableBody>
                    </Table>
                </AccordionContent>
            </AccordionItem>
            
            <AccordionItem value="products" className="border rounded-lg bg-card/50">
                <AccordionTrigger className="p-4 text-lg font-headline">
                    <div className='flex items-center gap-2'>
                        <Package className='h-5 w-5' />
                        Manage Products
                    </div>
                </AccordionTrigger>
                <AccordionContent className="px-4 pb-4">
                     <Table>
                        <TableHeader>
                            <TableRow>
                                <TableHead>Product</TableHead>
                                <TableHead>Price</TableHead>
                                <TableHead>Stock</TableHead>
                                <TableHead>Actions</TableHead>
                            </TableRow>
                        </TableHeader>
                        <TableBody>
                            {myProducts.map(product => (
                                <TableRow key={product.id}>
                                    <TableCell>
                                        <div className="flex items-center gap-3">
                                            <Image src={product.imageUrls[0]} alt={product.name} width={40} height={40} className="rounded-md object-cover" />
                                            <span className="font-medium">{product.name}</span>
                                        </div>
                                    </TableCell>
                                    <TableCell>₹{product.price.toLocaleString()}</TableCell>
                                    <TableCell>
                                        {product.stock !== undefined ? (
                                            <Badge variant={product.stock > 0 ? 'default' : 'destructive'}>
                                                {product.stock > 0 ? `${product.stock} in stock` : 'Out of stock'}
                                            </Badge>
                                        ) : (
                                            <Badge variant="secondary">N/A</Badge>
                                        )}
                                    </TableCell>
                                    <TableCell>
                                        <div className="flex gap-2">
                                            <Button variant="outline" size="icon">
                                                <Edit className="h-4 w-4" />
                                            </Button>
                                                <Button variant="destructive" size="icon">
                                                <Trash2 className="h-4 w-4" />
                                            </Button>
                                        </div>
                                    </TableCell>
                                </TableRow>
                            ))}
                        </TableBody>
                    </Table>
                </AccordionContent>
            </AccordionItem>
        </Accordion>
    </div>
  );
}


    

    

    
