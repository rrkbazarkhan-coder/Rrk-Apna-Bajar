

'use client';

import { useState } from 'react';
import { useApp } from '@/hooks/use-app';
import { notFound, useRouter, useParams } from 'next/navigation';
import Image from 'next/image';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ShoppingCart, Zap, ShieldCheck, ShoppingBag, Store, ChevronRight, MapPin } from 'lucide-react';
import { useCart } from '@/hooks/use-cart';
import { Carousel, CarouselContent, CarouselItem, CarouselNext, CarouselPrevious } from '@/components/ui/carousel';
import { ProductGrid } from '@/components/product-grid';
import { Separator } from '@/components/ui/separator';
import { cn } from '@/lib/utils';
import Link from 'next/link';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { useLocation } from '@/hooks/use-location';
import { getDistance } from '@/lib/utils';


export default function ProductDetailPage() {
    const { products, stores } = useApp();
    const { address } = useLocation();
    const { addToCart } = useCart();
    const router = useRouter();
    const params = useParams<{ id: string }>();
    const productId = parseInt(params.id, 10);
    const product = products.find(p => p.id === productId);

    const [selectedImage, setSelectedImage] = useState<string | null>(null);

    if (!product) {
        notFound();
    }
    
    const store = stores.find(s => s.id === product.storeId);
    const sellerProductsCount = products.filter(p => p.storeId === product.storeId).length;

    const relatedProducts = products.filter(p => p.category === product.category && p.id !== product.id && p.location === product.location);

    const getDiscount = () => {
        if (product.mrp && product.mrp > product.price) {
            return Math.round(((product.mrp - product.price) / product.mrp) * 100);
        }
        return 0;
    }
    
    const getProductDistance = () => {
      if (address?.lat && address?.lng && store?.lat && store?.lng) {
          const distance = getDistance(address.lat, address.lng, store.lat, store.lng);
          return `${distance.toFixed(1)} km away`;
      }
      return null;
    }

    const discount = getDiscount();
    const distance = getProductDistance();

    const handleBuyNow = () => {
        addToCart(product);
        router.push('/cart');
    }
    
    const mainImage = selectedImage || product.imageUrls[0];

    return (
        <div className="max-w-6xl mx-auto">
            <div className="grid md:grid-cols-2 gap-8">
                <div>
                     <div className="aspect-square relative rounded-lg overflow-hidden border mb-4">
                        <Image
                            src={mainImage}
                            alt={product.name}
                            fill
                            className="object-cover"
                            data-ai-hint="product photo"
                        />
                    </div>

                    <Carousel opts={{ align: "start", dragFree: true }}>
                        <CarouselContent className="-ml-2">
                             {product.imageUrls.map((url, index) => (
                                <CarouselItem key={index} className="basis-1/4 pl-2">
                                     <div 
                                        className={cn("aspect-square relative rounded-md overflow-hidden border cursor-pointer", mainImage === url && "border-primary border-2")}
                                        onClick={() => setSelectedImage(url)}
                                    >
                                        <Image
                                            src={url}
                                            alt={`${product.name} thumbnail ${index + 1}`}
                                            fill
                                            className="object-cover"
                                        />
                                    </div>
                                </CarouselItem>
                            ))}
                            {product.videoUrl && (
                                <CarouselItem className="basis-1/4 pl-2">
                                    <div className="aspect-square relative rounded-md overflow-hidden border bg-black cursor-pointer">
                                        <video
                                            src={product.videoUrl}
                                            className="w-full h-full object-contain"
                                            muted
                                            loop
                                            playsInline
                                            onClick={() => setSelectedImage(null)} // Or handle video display differently
                                        />
                                    </div>
                                </CarouselItem>
                            )}
                        </CarouselContent>
                    </Carousel>

                </div>
                <div>
                    <Card className="bg-card/50">
                        <CardContent className="pt-6 space-y-4">
                            <h1 className="text-3xl font-headline font-bold text-primary">{product.name}</h1>
                            <p className="text-muted-foreground">{product.description}</p>
                            
                            <div className="flex items-baseline gap-2">
                                <p className="text-3xl font-bold text-primary">₹{product.price.toLocaleString()}</p>
                                {product.mrp && product.mrp > product.price && (
                                    <p className="text-xl text-muted-foreground line-through">
                                        ₹{product.mrp.toLocaleString()}
                                    </p>
                                )}
                                {discount > 0 && (
                                    <Badge variant="destructive">{discount}% OFF</Badge>
                                )}
                            </div>
                            
                            { (product.sizes && product.sizes.length > 0) && (
                                <div className="flex items-center gap-2">
                                    <h3 className="font-semibold">Sizes:</h3>
                                    <div className="flex flex-wrap gap-2">
                                        {product.sizes.map(size => <Badge key={size} variant="outline">{size}</Badge>)}
                                    </div>
                                </div>
                            )}

                             { (product.colors && product.colors.length > 0) && (
                                <div className="space-y-2">
                                    <h3 className="font-semibold">Colors:</h3>
                                    <div className="flex flex-wrap gap-2">
                                        {product.colors.map(color => (
                                             <div key={color.name} onClick={() => setSelectedImage(color.imageUrl)} className="cursor-pointer">
                                                <Image 
                                                    src={color.imageUrl} 
                                                    alt={color.name}
                                                    width={50}
                                                    height={50}
                                                    className={cn("rounded-md border-2 object-cover aspect-square", selectedImage === color.imageUrl ? 'border-primary' : 'border-transparent')}
                                                />
                                                <p className="text-xs text-center mt-1">{color.name}</p>
                                             </div>
                                        ))}
                                    </div>
                                </div>
                            )}

                             <div className="space-y-3 pt-2">
                                {distance && (
                                    <div className="flex items-center gap-2 text-muted-foreground">
                                        <MapPin className="h-5 w-5" />
                                        <span className="font-semibold">Approx. {distance}</span>
                                    </div>
                                )}
                                {product.freeDelivery && (
                                    <div className="flex items-center gap-2 text-green-600">
                                        <Zap className="h-5 w-5" />
                                        <span className="font-semibold">Free Delivery Available</span>
                                    </div>
                                )}
                                 {product.returnPolicy && product.returnPolicy !== "No Returns" && (
                                    <div className="flex items-center gap-2 text-muted-foreground">
                                        <ShieldCheck className="h-5 w-5" />
                                        <span>{product.returnPolicy}</span>
                                    </div>
                                )}
                            </div>

                            <div className="flex gap-4 pt-4">
                                <Button onClick={() => addToCart(product)} size="lg" className="w-full" variant="outline">
                                    <ShoppingCart className="mr-2 h-5 w-5" />
                                    Add to Cart
                                </Button>
                                <Button onClick={handleBuyNow} size="lg" className="w-full bg-accent hover:bg-accent/90">
                                    <ShoppingBag className="mr-2 h-5 w-5" />
                                    Buy Now
                                </Button>
                            </div>
                        </CardContent>
                    </Card>

                    {store && (
                        <Card className="mt-6 bg-card/50">
                            <CardHeader>
                                <CardTitle className="text-xl flex items-center gap-2">
                                    <Store className="h-5 w-5" />
                                    Sold By
                                </CardTitle>
                            </CardHeader>
                            <CardContent>
                                <div className="flex justify-between items-center">
                                    <div className="flex items-center gap-3">
                                        <Avatar>
                                            <AvatarImage src={store.sellerPhotoUrl} alt={store.sellerName} />
                                            <AvatarFallback>{store.sellerName.charAt(0)}</AvatarFallback>
                                        </Avatar>
                                        <div>
                                            <p className="font-bold">{store.name}</p>
                                            <p className="text-sm text-muted-foreground">{sellerProductsCount} Products</p>
                                        </div>
                                    </div>
                                    <Button asChild variant="outline" size="sm">
                                        <Link href={`/store/${store.id}`}>
                                            View Store <ChevronRight className="h-4 w-4 ml-1" />
                                        </Link>
                                    </Button>
                                </div>
                            </CardContent>
                        </Card>
                    )}
                </div>
            </div>
            
            {relatedProducts.length > 0 && (
                <div className="mt-12">
                    <Separator className="my-6" />
                    <h2 className="text-2xl font-headline font-bold text-center mb-6">You might also like</h2>
                    <ProductGrid 
                        products={relatedProducts} 
                        selectedCategory={product.category}
                        limit={4} 
                        hideFiltering
                    />
                </div>
            )}
        </div>
    );
}
