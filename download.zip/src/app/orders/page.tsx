
'use client';

import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { Badge } from '@/components/ui/badge';
import { Truck, CheckCircle, Clock, XCircle } from 'lucide-react';
import Link from 'next/link';
import { useApp } from '@/hooks/use-app';

const statusConfig: {[key: string]: { icon: React.ElementType, color: string, bg: string }} = {
    Delivered: { icon: CheckCircle, color: 'text-green-600', bg: 'bg-green-50' },
    Pending: { icon: Clock, color: 'text-yellow-600', bg: 'bg-yellow-50' },
    Cancelled: { icon: XCircle, color: 'text-red-600', bg: 'bg-red-50' },
    Confirmed: { icon: CheckCircle, color: 'text-blue-600', bg: 'bg-blue-50' },
}

export default function OrdersPage() {
    const { orders } = useApp();

    if (orders.length === 0) {
        return (
             <div className="text-center py-20">
                <h1 className="text-4xl font-headline text-primary mb-4">You have no orders</h1>
                <p className="text-muted-foreground mb-6">Looks like you haven't made any purchases yet.</p>
                <Button asChild>
                <Link href="/">Start Shopping</Link>
                </Button>
            </div>
        )
    }

  return (
    <div className="max-w-4xl mx-auto">
        <header className="text-center mb-8">
            <h1 className="text-4xl md:text-5xl font-headline text-primary font-bold">My Orders</h1>
            <p className="text-lg text-muted-foreground mt-2">Track and view your order history.</p>
        </header>

        <div className="space-y-6">
            {orders.map(order => {
                const statusInfo = statusConfig[order.status] || statusConfig.Pending;
                const StatusIcon = statusInfo.icon;
                const address = order.shippingAddress;
                return (
                    <Card key={order.id} className="bg-card/50">
                        <CardHeader className="grid grid-cols-2 md:grid-cols-4 gap-4">
                            <div>
                                <CardDescription>Order ID</CardDescription>
                                <p className="font-semibold">{order.id}</p>
                            </div>
                            <div>
                                <CardDescription>Date</CardDescription>
                                <p className="font-semibold">{order.date}</p>
                            </div>
                            <div>
                                <CardDescription>Total</CardDescription>
                                <p className="font-semibold">₹{order.total.toLocaleString()}</p>
                            </div>
                            <div className="flex justify-start md:justify-end">
                                <Badge variant={order.status === 'Cancelled' ? 'destructive' : 'default'} className={`text-base ${statusInfo.bg} ${statusInfo.color} hover:${statusInfo.bg}`}>
                                    <StatusIcon className="mr-2 h-5 w-5"/>
                                    {order.status}
                                </Badge>
                            </div>
                        </CardHeader>
                        <Separator />
                        <CardContent className="pt-6">
                           <div className="grid md:grid-cols-2 gap-4">
                                <div>
                                    <h4 className="font-semibold mb-2">Items</h4>
                                    <div className="space-y-2">
                                        {order.items.map((item, index) => (
                                           <div key={index} className="flex items-center gap-4">
                                               <img src={item.imageUrl} alt={item.name} className="w-16 h-16 rounded-md object-cover" />
                                               <div>
                                                   <p className="font-semibold">{item.name}</p>
                                                   <p className="text-sm text-muted-foreground">Quantity: {item.quantity}</p>
                                               </div>
                                           </div>
                                        ))}
                                    </div>
                                </div>
                                <div>
                                    <h4 className="font-semibold mb-2">Shipping To</h4>
                                     <div className="text-sm">
                                        <p className="font-bold">{order.buyerName}</p>
                                        <p>{address.street}</p>
                                        {address.landmark && <p className="text-muted-foreground">Landmark: {address.landmark}</p>}
                                        <p>{address.city}, {address.state} - {address.pincode}</p>
                                    </div>
                                </div>
                           </div>
                        </CardContent>
                        <CardFooter className="gap-4">
                            <Button variant="outline">
                                <Truck className="mr-2 h-4 w-4" />
                                Track Order
                            </Button>
                             <Button variant="ghost">View Details</Button>
                        </CardFooter>
                    </Card>
                )
            })}
        </div>
    </div>
  );
}
