
'use client';

import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { MapPin, ShoppingBag, Edit, LogOut, Store, Settings, Heart, HelpCircle, ChevronRight, Phone, MessageSquare, Loader2 } from "lucide-react";
import Link from "next/link";
import { useEffect } from "react";
import { useAuth } from "@/hooks/use-auth";
import { useRouter } from "next/navigation";


const profileMenuItems = [
    { icon: ShoppingBag, label: "My Orders", href:"/orders" },
    { icon: Heart, label: "Wishlist", href:"#" },
    { icon: Store, label: "Start Selling", href:"/sell" },
    { icon: Settings, label: "Account Settings", href:"/profile/settings" },
]


export default function ProfilePage() {
    const { user, loading, signOut } = useAuth();
    const router = useRouter();

    useEffect(() => {
        if (!loading && !user) {
            router.push('/login');
        }
    }, [user, loading, router]);


    if (loading || !user) {
        return (
            <div className="flex justify-center items-center min-h-[calc(100vh-200px)]">
                <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
        );
    }

    return (
        <div className="max-w-4xl mx-auto">
            <Card className="bg-card/50">
                <CardContent className="pt-6">
                    <div className="flex items-center space-x-4">
                        <Avatar className="w-20 h-20 border-2 border-primary">
                            <AvatarImage src={user.photoURL || undefined} alt={user.displayName || 'User'} />
                            <AvatarFallback>{user.displayName ? user.displayName.charAt(0) : 'U'}</AvatarFallback>
                        </Avatar>
                        <div>
                            <h2 className="text-2xl font-bold font-headline">{user.displayName}</h2>
                            <p className="text-muted-foreground">{user.email}</p>
                        </div>
                    </div>
                </CardContent>
            </Card>

            <Card className="bg-card/50 mt-6">
                 <CardContent className="pt-6">
                    <div className="space-y-2">
                        {profileMenuItems.map(item => (
                             <Link key={item.label} href={item.href} className="flex items-center justify-between p-3 rounded-lg hover:bg-muted">
                                <div className="flex items-center space-x-4">
                                    <item.icon className="h-6 w-6 text-primary" />
                                    <span className="text-lg">{item.label}</span>
                                </div>
                                <ChevronRight className="h-5 w-5 text-muted-foreground"/>
                             </Link>
                        ))}
                        <Dialog>
                            <DialogTrigger asChild>
                                <div className="flex items-center justify-between p-3 rounded-lg hover:bg-muted cursor-pointer">
                                    <div className="flex items-center space-x-4">
                                        <HelpCircle className="h-6 w-6 text-primary" />
                                        <span className="text-lg">Help Center</span>
                                    </div>
                                    <ChevronRight className="h-5 w-5 text-muted-foreground"/>
                                </div>
                            </DialogTrigger>
                            <DialogContent>
                                <DialogHeader>
                                <DialogTitle>Contact Support</DialogTitle>
                                <DialogDescription>
                                    Reach out to us for any help or queries.
                                </DialogDescription>
                                </DialogHeader>
                                <div className="space-y-4 py-4">
                                    <a href="tel:9748980492" className="flex items-center gap-4 p-3 rounded-lg bg-muted">
                                        <Phone className="h-6 w-6 text-primary" />
                                        <div>
                                            <p className="font-semibold">MD Chand Khan</p>
                                            <p className="text-muted-foreground">9748980492</p>
                                        </div>
                                    </a>
                                    <a href="https://wa.me/916299546343" target="_blank" rel="noopener noreferrer" className="flex items-center gap-4 p-3 rounded-lg bg-muted">
                                        <MessageSquare className="h-6 w-6 text-green-500" />
                                        <div>
                                            <p className="font-semibold">MD Chand</p>
                                            <p className="text-muted-foreground">6299546343</p>
                                        </div>
                                    </a>
                                </div>
                            </DialogContent>
                        </Dialog>
                    </div>
                    <Separator className="my-4"/>
                    <Button variant="outline" className="w-full justify-center" onClick={signOut}>
                        <LogOut className="mr-2 h-5 w-5" /> Logout
                     </Button>
                </CardContent>
            </Card>
        </div>
    );
}
