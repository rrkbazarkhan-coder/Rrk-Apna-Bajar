
'use client';

import { useState, useEffect } from 'react';
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';
import { User, Mail, Phone, Lock, Home, Trash2, Loader2 } from 'lucide-react';
import { useAuth } from '@/hooks/use-auth';
import { useRouter } from 'next/navigation';

export default function AccountSettingsPage() {
    const { user, loading } = useAuth();
    const router = useRouter();
    const { toast } = useToast();
    const [phoneNumber, setPhoneNumber] = useState('');
    
    useEffect(() => {
        if (!loading && !user) {
            router.push('/login');
        } else if (user) {
            setPhoneNumber(user.phoneNumber || '');
        }
    }, [user, loading, router]);
    
    const handleSaveChanges = () => {
        // Here you would typically update the user's profile
        // For now, we'll just show a toast
        toast({
            title: "Success!",
            description: "Your information has been updated.",
        });
    };

    if (loading || !user) {
        return (
            <div className="flex justify-center items-center min-h-[calc(100vh-200px)]">
                <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
        );
    }


    return (
        <div className="max-w-4xl mx-auto space-y-8">
            <header>
                <h1 className="text-4xl font-headline text-primary font-bold">Account Settings</h1>
                <p className="text-lg text-muted-foreground mt-1">Manage your account details and preferences.</p>
            </header>

            {/* Personal Information Card */}
            <Card>
                <CardHeader>
                    <CardTitle>Personal Information</CardTitle>
                    <CardDescription>View and update your personal details.</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                    <div className="flex items-center gap-4">
                        <Avatar className="w-24 h-24 border-2 border-primary">
                            <AvatarImage src={user.photoURL || undefined} alt={user.displayName || 'User'} />
                            <AvatarFallback>{user.displayName ? user.displayName.charAt(0) : 'U'}</AvatarFallback>
                        </Avatar>
                         <div className='text-sm text-muted-foreground'>
                            This is your profile picture from your Google/Facebook account.
                        </div>
                    </div>
                    <div className="space-y-2">
                        <Label htmlFor="name">Name</Label>
                        <div className="flex items-center gap-2">
                            <User className="h-5 w-5 text-muted-foreground" />
                            <Input id="name" defaultValue={user.displayName || ''} readOnly disabled />
                        </div>
                    </div>
                    <div className="space-y-2">
                        <Label htmlFor="email">Email</Label>
                         <div className="flex items-center gap-2">
                            <Mail className="h-5 w-5 text-muted-foreground" />
                            <Input id="email" type="email" defaultValue={user.email || ''} readOnly disabled />
                        </div>
                    </div>
                    <div className="space-y-2">
                        <Label htmlFor="phone">Phone Number</Label>
                         <div className="flex items-center gap-2">
                            <Phone className="h-5 w-5 text-muted-foreground" />
                            <Input 
                                id="phone" 
                                type="tel" 
                                value={phoneNumber} 
                                onChange={(e) => setPhoneNumber(e.target.value)} 
                                placeholder="Phone number not set"
                            />
                        </div>
                    </div>
                     <Button onClick={handleSaveChanges}>Save Changes</Button>
                </CardContent>
            </Card>

            {/* Manage Addresses Card */}
            <Card>
                <CardHeader>
                    <CardTitle>Manage Addresses</CardTitle>
                    <CardDescription>Add, edit, or remove your shipping addresses.</CardDescription>
                </CardHeader>
                <CardContent>
                    {/* Placeholder for address management */}
                    <div className="border border-dashed rounded-lg p-8 text-center">
                        <p className="text-muted-foreground">Address management is coming soon.</p>
                    </div>
                </CardContent>
            </Card>

            {/* Security Card */}
            <Card>
                <CardHeader>
                    <CardTitle>Security</CardTitle>
                    <CardDescription>Password management is not applicable for social logins.</CardDescription>
                </CardHeader>
                 <CardContent>
                    <p className="text-sm text-muted-foreground">You are signed in via a social provider. To change your password, please do so on that platform.</p>
                </CardContent>
            </Card>
        </div>
    );
}
