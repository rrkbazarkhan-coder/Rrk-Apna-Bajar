
'use client';

import { useCart } from "@/hooks/use-cart";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/hooks/use-toast";
import Link from 'next/link';
import { CartItem as CartItemComponent } from "@/components/cart-item";
import { CreditCard, Truck, User, Phone, MapPin, CheckCircle } from "lucide-react";
import { AudioGuide } from "@/components/audio-guide";
import { useState } from "react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { useApp } from "@/hooks/use-app";
import { useLocation } from "@/hooks/use-location";
import { Order, UserAddress } from "@/lib/types";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { SetAddressDialog } from "@/components/set-address-dialog";

export default function CartPage() {
  const { cart, cartCount, cartTotal, clearCart } = useCart();
  const { addOrder } = useApp();
  const { address: deliveryAddress, setAddress: setDeliveryAddress } = useLocation();
  const { toast } = useToast();
  const [buyerPhoto, setBuyerPhoto] = useState<string | null>(null);
  const [buyerName, setBuyerName] = useState('');
  const [phone, setPhone] = useState('');

  const [isConfirmed, setIsConfirmed] = useState(false);

  const handlePlaceOrder = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (cartCount > 0 && buyerName && buyerPhoto && phone && deliveryAddress && isConfirmed) {
      
      const newOrder: Order = {
        id: `RRK-${Date.now()}`,
        date: new Date().toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' }),
        status: 'Pending',
        total: cartTotal,
        items: cart.map(cartItem => ({ 
            name: cartItem.product.name, 
            quantity: cartItem.quantity, 
            imageUrl: cartItem.product.imageUrls[0] 
        })),
        buyerName,
        buyerPhoto,
        shippingAddress: deliveryAddress,
      };

      addOrder(newOrder);

      toast({
        title: "Order Placed!",
        description: "Thank you for your purchase. Your order will be delivered soon.",
      });
      clearCart();
    } else if (!isConfirmed) {
        toast({
            variant: "destructive",
            title: "Please Confirm Location",
            description: "You must confirm your delivery location before placing the order."
        })
    }
  };

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setBuyerPhoto(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  if (cartCount === 0) {
    return (
      <div className="text-center py-20">
        <h1 className="text-4xl font-headline text-primary mb-4">Your Cart is Empty</h1>
        <p className="text-muted-foreground mb-6">Looks like you haven't added anything to your cart yet.</p>
        <Button asChild>
          <Link href="/">Start Shopping</Link>
        </Button>
      </div>
    );
  }

  const grandTotal = cartTotal;

  const checkoutAudioGuideText = `
    चेकआउट पूरा करने के लिए कृपया यह जानकारी भरें.
    पहला, अपनी एक तस्वीर अपलोड करें.
    दूसरा, अपना पूरा नाम दर्ज करें.
    तीसरा, अपना 10 अंकों का मोबाइल नंबर दर्ज करें.
    चौथा, अपना डिलीवरी का पता कन्फर्म करें.
  `;

  return (
    <div className="max-w-4xl mx-auto">
      <h1 className="text-4xl font-headline text-primary text-center mb-8">Your Shopping Cart</h1>
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
          <Card className="bg-card/50">
            <CardHeader>
              <CardTitle>Items ({cartCount})</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {cart.map(item => (
                  <CartItemComponent key={item.product.id} item={item} />
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="space-y-8">
          <Card className="bg-card/50">
            <CardHeader>
              <CardTitle>Order Summary</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex justify-between">
                <span>Subtotal</span>
                <span>₹{cartTotal.toLocaleString()}</span>
              </div>
              <Separator />
              <div className="flex justify-between font-bold text-lg">
                <span>Grand Total</span>
                <span>₹{grandTotal.toLocaleString()}</span>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-card/50">
            <CardHeader className="flex justify-between items-center">
              <CardTitle>Checkout</CardTitle>
              <AudioGuide text={checkoutAudioGuideText} />
            </CardHeader>
            <CardContent>
              <form onSubmit={handlePlaceOrder} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="buyer-photo">Your Photo</Label>
                  <div className="flex items-center gap-4">
                      <Avatar className="w-16 h-16">
                          <AvatarImage src={buyerPhoto || undefined} />
                          <AvatarFallback><User /></AvatarFallback>
                      </Avatar>
                      <Input id="buyer-photo" type="file" accept="image/*" onChange={handlePhotoUpload} required />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="name">Full Name</Label>
                  <Input id="name" value={buyerName} onChange={e => setBuyerName(e.target.value)} required />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="phone">Phone Number</Label>
                  <Input id="phone" type="tel" required placeholder="e.g., 9876543210" value={phone} onChange={e => setPhone(e.target.value)} />
                </div>

                <div className="space-y-2">
                    <Label>Delivery Location</Label>
                    {!deliveryAddress ? (
                        <Alert variant="destructive">
                            <AlertTitle>No Address Set</AlertTitle>
                            <AlertDescription>
                                Please set your delivery address.
                            </AlertDescription>
                        </Alert>
                    ) : (
                        <Card className="bg-background p-3">
                            <p className="font-semibold">{deliveryAddress.street}</p>
                            {deliveryAddress.landmark && <p className="text-sm text-muted-foreground">Landmark: {deliveryAddress.landmark}</p>}
                            <p className="text-sm text-muted-foreground">{deliveryAddress.city}, {deliveryAddress.state} - {deliveryAddress.pincode}</p>
                            {deliveryAddress.lat && deliveryAddress.lng && (
                                <p className="text-xs text-muted-foreground">Coords: {deliveryAddress.lat.toFixed(4)}, {deliveryAddress.lng.toFixed(4)}</p>
                            )}
                        </Card>
                    )}
                    <div className="flex gap-2">
                        <SetAddressDialog 
                            triggerButton={<Button type="button" variant="outline" className="w-full">Set/Change Address</Button>}
                        />
                        <Button type="button" onClick={() => setIsConfirmed(true)} disabled={!deliveryAddress} className="w-full">
                           <CheckCircle className="mr-2 h-4 w-4"/> Confirm
                        </Button>
                    </div>
                     {isConfirmed && (
                        <p className="text-sm text-green-600 flex items-center gap-2">
                            <CheckCircle className="h-4 w-4" /> Location Confirmed for this order.
                        </p>
                    )}
                </div>
                
                <div className="p-3 rounded-md bg-background border border-dashed flex items-center gap-3">
                  <CreditCard className="h-6 w-6 text-primary" />
                  <div>
                    <p className="font-semibold">Cash on Delivery (COD)</p>
                    <p className="text-sm text-muted-foreground">Pay upon arrival</p>
                  </div>
                </div>

                <Button type="submit" className="w-full bg-accent hover:bg-accent/90" size="lg" disabled={!isConfirmed}>
                  <Truck className="mr-2 h-5 w-5" />
                  Place Order
                </Button>
              </form>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
