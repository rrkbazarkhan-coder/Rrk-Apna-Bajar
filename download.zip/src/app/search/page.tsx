
'use client';

import { useState, useEffect, useRef } from 'react';
import { Input } from '@/components/ui/input';
import { ProductGrid } from '@/components/product-grid';
import { useApp } from '@/hooks/use-app';
import { Search as SearchIcon, Mic, Camera, X } from 'lucide-react';
import { useSearchParams } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';
import { Alert, AlertTitle, AlertDescription } from '@/components/ui/alert';

export default function SearchPage() {
    const { products, stores } = useApp();
    const { toast } = useToast();
    const searchParams = useSearchParams();
    const queryParam = searchParams.get('q') || '';

    const [searchTerm, setSearchTerm] = useState(queryParam);
    const [filteredProducts, setFilteredProducts] = useState(
        products.filter(p => p.name.toLowerCase().includes(queryParam.toLowerCase()))
    );
    const [isListening, setIsListening] = useState(false);
    const [isScanning, setIsScanning] = useState(false);
    const [hasCameraPermission, setHasCameraPermission] = useState<boolean | null>(null);

    const videoRef = useRef<HTMLVideoElement>(null);
    const recognitionRef = useRef<any>(null);

    useEffect(() => {
        if (!('webkitSpeechRecognition' in window)) {
            console.log("Speech recognition not supported");
        } else {
            const recognition = new (window as any).webkitSpeechRecognition();
            recognition.continuous = false;
            recognition.interimResults = false;
            recognition.lang = 'hi-IN';

            recognition.onresult = (event: any) => {
                const transcript = event.results[0][0].transcript;
                setSearchTerm(transcript);
                handleSearch(transcript);
                setIsListening(false);
            };

            recognition.onerror = (event: any) => {
                console.error("Speech recognition error", event.error);
                toast({ variant: 'destructive', title: 'Voice search error', description: event.error });
                setIsListening(false);
            };
            
            recognition.onend = () => {
                setIsListening(false);
            };

            recognitionRef.current = recognition;
        }
    }, [toast]);
    
     useEffect(() => {
        if (isScanning && hasCameraPermission) {
            const videoElement = videoRef.current;
            const stream = videoElement?.srcObject as MediaStream;
            if (!stream) return;

            const interval = setInterval(() => {
                // Placeholder for barcode scanning logic
                // In a real app, you would use a library like `zxing/library`
                // to decode the video stream and find a barcode.
                console.log("Scanning for barcode...");
            }, 1000);

            return () => clearInterval(interval);
        }
    }, [isScanning, hasCameraPermission]);


    const handleSearch = (term: string) => {
        const lowerCaseTerm = term.toLowerCase();
        setSearchTerm(term);

        if (term) {
             const storeMap = new Map(stores.map(store => [store.id, store.name.toLowerCase()]));
            
            setFilteredProducts(
                products.filter(p => {
                    const storeName = storeMap.get(p.storeId) || '';
                    return (
                        p.name.toLowerCase().includes(lowerCaseTerm) ||
                        p.description.toLowerCase().includes(lowerCaseTerm) ||
                        p.category.toLowerCase().includes(lowerCaseTerm) ||
                        storeName.includes(lowerCaseTerm)
                    )
                })
            );
        } else {
            setFilteredProducts([]);
        }
    };

    const handleVoiceSearch = () => {
        if (isListening) {
            recognitionRef.current?.stop();
            setIsListening(false);
        } else {
            recognitionRef.current?.start();
            setIsListening(true);
        }
    };

    const handleBarcodeScan = async () => {
        if (isScanning) {
            stopCamera();
            return;
        }

        setIsScanning(true);
        if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
            try {
                const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' } });
                setHasCameraPermission(true);
                if (videoRef.current) {
                    videoRef.current.srcObject = stream;
                }
            } catch (err) {
                console.error("Error accessing camera", err);
                setHasCameraPermission(false);
                setIsScanning(false);
                toast({
                    variant: 'destructive',
                    title: 'Camera Access Denied',
                    description: 'Please enable camera permissions in your browser settings to use this feature.',
                });
            }
        } else {
            setHasCameraPermission(false);
            setIsScanning(false);
             toast({
                variant: 'destructive',
                title: 'Camera Not Supported',
                description: 'Your browser does not support camera access.',
            });
        }
    };

    const stopCamera = () => {
        if (videoRef.current && videoRef.current.srcObject) {
            const stream = videoRef.current.srcObject as MediaStream;
            stream.getTracks().forEach(track => track.stop());
            videoRef.current.srcObject = null;
        }
        setIsScanning(false);
    };

    return (
        <div className="min-h-[calc(100vh-200px)] -m-8 -mb-32">
            <div className="relative bg-cover bg-center py-16 px-4" style={{ backgroundImage: "url('https://picsum.photos/seed/searchbg/1200/400')"}}>
                <div className="absolute inset-0 bg-black/50 backdrop-blur-sm"></div>
                 <div className="relative z-10 max-w-2xl mx-auto text-center">
                    <h1 className="text-4xl font-headline text-white mb-4">Search For Products</h1>
                    <p className="text-lg text-white/80 mb-6">Apne pasand ka samaan dhoondhein - type karein, bolein, ya scan karein!</p>
                     <div className="relative flex items-center">
                        <SearchIcon className="absolute left-4 h-6 w-6 text-muted-foreground" />
                        <Input 
                            placeholder="rrk Apna Bazar" 
                            className="pl-12 pr-24 text-lg h-14 rounded-full shadow-lg"
                            value={searchTerm}
                            onChange={(e) => handleSearch(e.target.value)}
                        />
                        <div className="absolute right-4 flex items-center gap-2">
                             <Button variant="ghost" size="icon" className="rounded-full h-10 w-10" onClick={handleVoiceSearch}>
                                <Mic className={isListening ? "text-red-500 animate-pulse" : ""} />
                            </Button>
                            <Button variant="ghost" size="icon" className="rounded-full h-10 w-10" onClick={handleBarcodeScan}>
                                <Camera />
                            </Button>
                        </div>
                    </div>
                 </div>
            </div>

            {isScanning && (
                <div className="p-4 bg-black">
                     <div className="max-w-md mx-auto relative">
                        <video ref={videoRef} className="w-full aspect-video rounded-md" autoPlay muted playsInline />
                         <div className="absolute inset-0 border-4 border-dashed border-green-500/50 m-8 rounded-lg"></div>
                        <Button onClick={stopCamera} variant="destructive" className="absolute top-2 right-2 rounded-full" size="icon">
                            <X />
                        </Button>
                         {hasCameraPermission === false && (
                            <Alert variant="destructive" className='mt-2'>
                                <AlertTitle>Camera Access Denied</AlertTitle>
                                <AlertDescription>Please grant camera permission to use the scanner.</AlertDescription>
                            </Alert>
                        )}
                    </div>
                </div>
            )}
            
            <div className="p-8">
                 {filteredProducts.length > 0 ? (
                    <ProductGrid products={filteredProducts} selectedCategory="All" />
                ) : (
                    <div className='text-center py-10'>
                       <p className='text-muted-foreground'>{searchTerm ? `No results found for "${searchTerm}"` : 'Start typing to search for products.'}</p>
                    </div>
                )}
            </div>
        </div>
    );
}
