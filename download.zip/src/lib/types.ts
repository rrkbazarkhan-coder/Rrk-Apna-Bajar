

export interface ColorVariant {
  name: string;
  imageUrl: string;
}

export interface Product {
  id: number;
  name: string;
  description: string;
  price: number;
  mrp?: number;
  imageUrls: string[];
  videoUrl?: string;
  location: string;
  storeId: number;
  category: string;
  rating: number;
  reviews: number;
  sizes?: string[];
  colors?: ColorVariant[];
  returnPolicy?: string;
  freeDelivery?: boolean;
  stock?: number;
  status: 'active' | 'pending' | 'rejected';
}

export interface Store {
  id: number;
  name:string;
  details: string;
  address: string;
  landmark?: string;
  city: string;
  pincode: string;
  lat?: number;
  lng?: number;
  sellerName: string;
  sellerEmail: string;
  sellerPhone: string;
  sellerPhotoUrl: string;
  paymentMethod: 'upi' | 'bank';
  upiId?: string;
  bankAccountName?: string;
  bankAccountNumber?: string;
  bankIfscCode?: string;
  status: 'active' | 'blocked';
  createdAt: string; // ISO date string
  userEmail: string;
}

export interface CartItem {
  product: Product;
  quantity: number;
}

export interface Category {
  name: string;
  imageUrl: string;
}

export interface City {
    name: string;
    pincode: string;
    lat: number;
    lng: number;
}

export interface UserAddress {
    street: string;
    landmark?: string;
    city: string;
    pincode: string;
    state?: string;
    country?: string;
    lat?: number;
    lng?: number;
}

export interface Order {
    id: string;
    date: string;
    status: 'Pending' | 'Confirmed' | 'Delivered' | 'Cancelled';
    total: number;
    items: {
        name: string;
        quantity: number;
        imageUrl: string;
    }[];
    buyerName: string;
    buyerPhoto: string;
    shippingAddress: UserAddress;
}
