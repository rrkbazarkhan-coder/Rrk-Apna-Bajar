
'use client';

import { initializeApp, getApp, getApps } from "firebase/app";
import { getAuth, createUserWithEmailAndPassword, signInWithEmailAndPassword, updateProfile } from "firebase/auth";

const firebaseConfig = {
  apiKey: "AIzaSyAGBpho-ynyrqNpVg-6ZMqRdiU7ddA9vN8",
  authDomain: "local-xchange-e9pvb.firebaseapp.com",
  databaseURL: "https://local-xchange-e9pvb-default-rtdb.firebaseio.com",
  projectId: "local-xchange-e9pvb",
  storageBucket: "local-xchange-e9pvb.firebasestorage.app",
  messagingSenderId: "712174961323",
  appId: "1:712174961323:web:b2b79cdb262e253117adee",
  measurementId: "G-DRZTL8YFXK"
};

// Initialize Firebase
const app = !getApps().length ? initializeApp(firebaseConfig) : getApp();
const auth = getAuth(app);


// --- Email/Password Auth Functions ---
const signUpWithEmail = async (email: string, password: string, name: string) => {
  const userCredential = await createUserWithEmailAndPassword(auth, email, password);
  if (userCredential.user) {
    await updateProfile(userCredential.user, { displayName: name });
  }
  return userCredential;
};

const signInWithEmail = async (email: string, password: string) => {
  return await signInWithEmailAndPassword(auth, email, password);
};


export { app, auth, signUpWithEmail, signInWithEmail };
