import { config } from 'dotenv';
config();

import '@/ai/flows/generate-product-description.ts';
import '@/ai/flows/text-to-speech.ts';
import '@/ai/flows/generate-product-details.ts';
