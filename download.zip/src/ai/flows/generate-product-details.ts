
'use server';

/**
 * @fileOverview Extracts product details from an image.
 *
 * - generateProductDetails - A function that extracts product details from a photo.
 * - GenerateProductDetailsInput - The input type for the generateProductDetails function.
 * - GenerateProductDetailsOutput - The return type for the generateProductDetails function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const GenerateProductDetailsInputSchema = z.object({
  productPhotoDataUri: z
    .string()
    .describe(
      "A photo of the product, as a data URI that must include a MIME type and use Base64 encoding. Expected format: 'data:<mimetype>;base64,<encoded_data>'."
    ),
});
export type GenerateProductDetailsInput = z.infer<typeof GenerateProductDetailsInputSchema>;

const GenerateProductDetailsOutputSchema = z.object({
  name: z.string().describe('A short, catchy name for the product.'),
  description: z.string().describe('A detailed and appealing description of the product, highlighting its key features and benefits.'),
  category: z.string().describe('The most relevant category for the product from a standard e-commerce list.'),
  mrp: z.coerce.number().describe('A reasonable Manufacturer\'s Suggested Retail Price (MRP) for the product in Indian Rupees (₹).').optional(),
  sizes: z.array(z.string()).optional().describe('A list of available sizes (e.g., S, M, L, XL or numerical sizes), if applicable.'),
  colors: z.array(z.string()).optional().describe('A list of available colors, if applicable.'),
});
export type GenerateProductDetailsOutput = z.infer<typeof GenerateProductDetailsOutputSchema>;

export async function generateProductDetails(
  input: GenerateProductDetailsInput
): Promise<GenerateProductDetailsOutput> {
  return generateProductDetailsFlow(input);
}

const prompt = ai.definePrompt({
  name: 'generateProductDetailsPrompt',
  input: {schema: GenerateProductDetailsInputSchema},
  output: {schema: GenerateProductDetailsOutputSchema},
  prompt: `You are an expert e-commerce merchandiser. Analyze the product in the provided image and generate the required details in the specified JSON format.

  Your goal is to provide accurate and appealing information that would help sell the product in an Indian marketplace.

  - **name**: Create a concise and attractive product name.
  - **description**: Write a compelling and detailed product description highlighting its key features and benefits. Make it at least 2-3 sentences long.
  - **category**: Assign the most fitting category.
  - **mrp**: Suggest a realistic Maximum Retail Price (MRP) in Indian Rupees (₹).
  - **sizes**: If applicable, list potential sizes.
  - **colors**: If applicable, list the primary colors.

  Photo: {{media url=productPhotoDataUri}}`,
});

const generateProductDetailsFlow = ai.defineFlow(
  {
    name: 'generateProductDetailsFlow',
    inputSchema: GenerateProductDetailsInputSchema,
    outputSchema: GenerateProductDetailsOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
