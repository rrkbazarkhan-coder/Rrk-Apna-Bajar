

'use client';

import Image from 'next/image';
import type { Product, Store } from '@/lib/types';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Star, MapPin } from 'lucide-react';
import { Badge } from './ui/badge';
import Link from 'next/link';
import { useLocation } from '@/hooks/use-location';
import { useApp } from '@/hooks/use-app';
import { getDistance } from '@/lib/utils';

interface ProductCardProps {
  product: Product;
}

export function ProductCard({ product }: ProductCardProps) {
  const { stores } = useApp();
  const { address } = useLocation();

  const getDiscount = () => {
    if (product.mrp && product.mrp > product.price) {
      return Math.round(((product.mrp - product.price) / product.mrp) * 100);
    }
    return 0;
  }
  
  const getProductDistance = () => {
      const store = stores.find(s => s.id === product.storeId);
      if (address?.lat && address?.lng && store?.lat && store?.lng) {
          const distance = getDistance(address.lat, address.lng, store.lat, store.lng);
          return `${distance.toFixed(1)} km away`;
      }
      return null;
  }

  const discount = getDiscount();
  const distance = getProductDistance();

  return (
    <Link href={`/product/${product.id}`} className="flex flex-col h-full group">
        <Card className="flex flex-col overflow-hidden rounded-lg shadow-md hover:shadow-xl transition-shadow duration-300 h-full bg-card/50 group-hover:border-primary">
        <CardHeader className="p-0">
            <div className="aspect-square relative">
            <Image
                src={product.imageUrls[0]}
                alt={product.name}
                fill
                className="object-cover"
                data-ai-hint="product photo"
            />
            {discount > 0 && (
                <Badge variant="destructive" className="absolute top-2 right-2">
                {discount}% OFF
                </Badge>
            )}
            </div>
        </CardHeader>
        <CardContent className="p-4 flex-grow">
            <CardTitle className="text-lg font-headline mb-1 leading-tight h-12 overflow-hidden">
                {product.name}
            </CardTitle>
            <div className="flex items-center gap-1 text-sm text-muted-foreground">
                <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                <span className="font-semibold">{product.rating}</span>
                <span>({product.reviews} reviews)</span>
            </div>
        </CardContent>
        <CardFooter className="p-4 mt-auto">
            <div className='flex flex-col'>
                <p className="text-xl font-bold text-primary">₹{product.price.toLocaleString()}</p>
                 <div className="flex items-baseline gap-2">
                    {product.mrp && product.mrp > product.price && (
                        <p className="text-sm text-muted-foreground line-through">
                            ₹{product.mrp.toLocaleString()}
                        </p>
                    )}
                    {distance && (
                         <div className="flex items-center text-xs text-muted-foreground gap-1">
                            <MapPin className="h-3 w-3" />
                            <span>Approx. {distance}</span>
                        </div>
                    )}
                </div>
            </div>
        </CardFooter>
        </Card>
    </Link>
  );
}
