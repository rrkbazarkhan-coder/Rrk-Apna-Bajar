
'use client';

import { useLocation } from '@/hooks/use-location';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { ChevronDown } from 'lucide-react';

export function LocationSelector() {
  const { setAddress, availableLocations, isDetecting } = useLocation();

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" className="flex" size="sm" disabled={isDetecting}>
          <ChevronDown className="mr-2 h-4 w-4" />
          Change
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end">
        {availableLocations.map((loc, index) => (
          <DropdownMenuItem key={loc.name} onSelect={() => setAddress({ city: loc.name, street: loc.name, pincode: loc.pincode, lat: loc.lat, lng: loc.lng } as any)} disabled={isDetecting}>
            {loc.name}
          </DropdownMenuItem>
        ))}
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
