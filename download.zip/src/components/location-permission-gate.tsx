
'use client';

import { useLocation } from '@/hooks/use-location';
import { Button } from './ui/button';
import { Card, CardDescription, CardHeader, CardTitle, CardContent } from './ui/card';
import { Info, RotateCw, MapPin, XCircle, Loader2 } from 'lucide-react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { useToast } from '@/hooks/use-toast';
import type { UserAddress } from '@/lib/types';
import { SetAddressDialog } from './set-address-dialog';

export function LocationPermissionGate() {
  const { permissionState, detectLocation, availableLocations, setAddress, isDetecting, useLastKnownLocation, lastKnownLocation } = useLocation();
  const { toast } = useToast();

  const handleManualSelect = (city: string) => {
    const selectedCity = availableLocations.find(c => c.name === city);
    if(selectedCity) {
      const newAddress: UserAddress = {
        street: selectedCity.name,
        city: selectedCity.name,
        pincode: selectedCity.pincode,
        state: '',
        country: 'India',
        lat: selectedCity.lat,
        lng: selectedCity.lng
      };
      setAddress(newAddress);
    }
  }

  const handleDetectClick = async () => {
    if (permissionState === 'prompt') {
       toast({
           title: 'Delivery ke liye app ko location permission chahiye.',
           description: 'Kripya browser pop-up me "Allow" par click karein.'
       });
    }
    const result = await detectLocation();
    if (!result.success) {
        if(permissionState === 'denied'){
            toast({
                title: 'Kripya location allow karein',
                description: 'Aapko browser settings me jaakar location permission on karni hogi.',
                variant: 'destructive'
            });
        }
    }
  }


  return (
    <Card className="max-w-md mx-auto">
      <CardHeader className="text-center">
        <MapPin className="w-12 h-12 text-primary mx-auto" />
        <CardTitle className="text-primary mt-2">Apni Delivery Location Set Karein</CardTitle>
        <CardDescription>
          Yeh batayein ki aapko samaan kahan mangwana hai.
        </CardDescription>
      </CardHeader>
      <CardContent className="flex flex-col gap-4 items-center">
        <Button onClick={handleDetectClick} disabled={isDetecting} className="w-full">
            {isDetecting ? (
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            ) : (
                <RotateCw className="mr-2 h-4 w-4" />
            )}
            Auto-Detect Location (GPS)
        </Button>
        
        <div className="w-full text-center">
            <p className="text-sm text-muted-foreground mb-2">--- Ya ---</p>
             <SetAddressDialog triggerButton={
                <Button variant="outline" className="w-full">Address Manually Daalein</Button>
            } />
        </div>
        
        {lastKnownLocation && (
             <div className="w-full text-center">
                <p className="text-sm text-muted-foreground mb-2">--- Ya ---</p>
                <Button variant="secondary" className="w-full" onClick={useLastKnownLocation}>
                    Use last known location: {lastKnownLocation}
                </Button>
            </div>
        )}
      </CardContent>
    </Card>
  );
}
