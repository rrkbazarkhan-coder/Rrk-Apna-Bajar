
'use client';

import { SidebarContent, SidebarHeader, SidebarMenu, SidebarMenuItem, SidebarMenuButton } from "./ui/sidebar";
import { useCategory } from '@/hooks/use-category';
import Image from "next/image";

export function AppSidebar() {
    const { categories, selectedCategory, setSelectedCategory } = useCategory();

    return (
        <>
            <SidebarHeader>
                <h2 className="text-xl font-bold">Categories</h2>
            </SidebarHeader>
            <SidebarContent>
                <SidebarMenu>
                    <SidebarMenuItem>
                        <SidebarMenuButton
                            onClick={() => setSelectedCategory('All')}
                            isActive={selectedCategory === 'All'}
                        >
                            All Categories
                        </SidebarMenuButton>
                    </SidebarMenuItem>
                    {categories.map((category) => (
                        <SidebarMenuItem key={category.name}>
                            <SidebarMenuButton
                                onClick={() => setSelectedCategory(category.name)}
                                isActive={selectedCategory === category.name}
                                className="h-12"
                            >
                                <Image
                                    src={category.imageUrl}
                                    alt={category.name}
                                    width={32}
                                    height={32}
                                    className="rounded-md object-cover"
                                    data-ai-hint="category image"
                                />
                                <span>{category.name}</span>
                            </SidebarMenuButton>
                        </SidebarMenuItem>
                    ))}
                </SidebarMenu>
            </SidebarContent>
        </>
    )
}
