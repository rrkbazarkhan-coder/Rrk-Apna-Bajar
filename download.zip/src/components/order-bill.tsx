
'use client';

import type { Order, Store } from '@/lib/types';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from './ui/table';
import { Separator } from './ui/separator';
import { Button } from './ui/button';
import { Printer } from 'lucide-react';

interface OrderBillProps {
  order: Order;
  store: Store;
}

export function OrderBill({ order, store }: OrderBillProps) {
  
  const handlePrint = () => {
    window.print();
  };

  return (
    <Card className="font-sans">
      <style>
        {`
          @media print {
            body * {
              visibility: hidden;
            }
            #printable-bill, #printable-bill * {
              visibility: visible;
            }
            #printable-bill {
              position: absolute;
              left: 0;
              top: 0;
              width: 100%;
            }
            #print-button {
              display: none;
            }
          }
        `}
      </style>
      <div id="printable-bill">
        <CardHeader className="text-center">
            <CardTitle className="text-2xl font-bold">Tax Invoice</CardTitle>
            <CardDescription>{store.name}</CardDescription>
        </CardHeader>
        <CardContent className="text-sm">
            <div className="grid grid-cols-2 gap-4 mb-4">
                <div>
                    <h3 className="font-semibold">Billed To:</h3>
                    <p>{order.buyerName}</p>
                    <p>{order.shippingAddress.street}</p>
                    <p>{order.shippingAddress.city}, {order.shippingAddress.pincode}</p>
                </div>
                 <div className="text-right">
                    <p><span className="font-semibold">Invoice #:</span> {order.id}</p>
                    <p><span className="font-semibold">Date:</span> {new Date(order.date).toLocaleDateString()}</p>
                </div>
            </div>

            <Separator className="my-4"/>

            <Table>
                <TableHeader>
                    <TableRow>
                        <TableHead>Item</TableHead>
                        <TableHead>Qty</TableHead>
                        <TableHead className="text-right">Total</TableHead>
                    </TableRow>
                </TableHeader>
                <TableBody>
                    {order.items.map((item, index) => {
                        const product = { price: order.total / item.quantity }; // Simplified for now
                        return(
                            <TableRow key={index}>
                                <TableCell>{item.name}</TableCell>
                                <TableCell>{item.quantity}</TableCell>
                                <TableCell className="text-right">₹{(product.price * item.quantity).toLocaleString()}</TableCell>
                            </TableRow>
                        )
                    })}
                </TableBody>
            </Table>
            
             <Separator className="my-4"/>

             <div className="flex justify-end">
                <div className="w-full max-w-xs space-y-2">
                    <div className="flex justify-between font-bold text-base">
                        <span>Grand Total:</span>
                        <span>₹{order.total.toLocaleString()}</span>
                    </div>
                     <p className="text-xs text-muted-foreground text-right">Payment Mode: Cash on Delivery</p>
                </div>
             </div>

            <Separator className="my-4"/>

            <div className="text-center text-xs text-muted-foreground">
                <p>Thank you for your business!</p>
                <p>This is a computer generated invoice.</p>
            </div>
        </CardContent>
      </div>
       <div className="p-6 pt-0 text-center">
        <Button id="print-button" onClick={handlePrint}><Printer className="mr-2 h-4 w-4" /> Print Invoice</Button>
      </div>
    </Card>
  );
}
