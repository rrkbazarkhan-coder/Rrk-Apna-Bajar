
export function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="border-t mt-auto">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-4 text-center text-muted-foreground">
        <p className="text-sm">
          &copy; {currentYear} Local Xchange. All Rights Reserved.
        </p>
      </div>
    </footer>
  );
}
