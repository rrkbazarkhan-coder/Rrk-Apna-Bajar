
'use client';

import Image from 'next/image';
import type { CartItem as CartItemType } from '@/lib/types';
import { useCart } from '@/hooks/use-cart';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { X } from 'lucide-react';

interface CartItemProps {
  item: CartItemType;
}

export function CartItem({ item }: CartItemProps) {
  const { updateQuantity, removeFromCart } = useCart();

  return (
    <div className="flex items-center gap-4">
      <div className="relative h-24 w-24 rounded-md overflow-hidden flex-shrink-0">
        <Image
          src={item.product.imageUrls[0]}
          alt={item.product.name}
          fill
          className="object-cover"
          data-ai-hint="product photo"
        />
      </div>
      <div className="flex-grow">
        <h3 className="font-semibold font-headline">{item.product.name}</h3>
        <p className="text-sm text-muted-foreground">₹{item.product.price.toLocaleString()}</p>
      </div>
      <div className="flex items-center gap-2">
        <Input
          type="number"
          min="1"
          value={item.quantity}
          onChange={(e) => updateQuantity(item.product.id, parseInt(e.target.value, 10))}
          className="w-16 h-9 text-center"
        />
        <Button
          variant="ghost"
          size="icon"
          onClick={() => removeFromCart(item.product.id)}
          className="text-muted-foreground hover:text-destructive"
        >
          <X className="h-5 w-5" />
          <span className="sr-only">Remove item</span>
        </Button>
      </div>
    </div>
  );
}
