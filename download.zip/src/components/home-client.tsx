
'use client';

import { useState } from 'react';
import Image from 'next/image';
import { ProductGrid } from '@/components/product-grid';
import type { Product, Category } from '@/lib/types';
import { Carousel, CarouselContent, CarouselItem, CarouselNext, CarouselPrevious } from '@/components/ui/carousel';
import { useCategory } from '@/hooks/use-category';
import { SidebarTrigger } from './ui/sidebar';
import { Card, CardContent } from './ui/card';
import { LocationBar } from './location-bar';
import { Input } from './ui/input';
import { Search } from 'lucide-react';
import { useRouter } from 'next/navigation';

interface HomeClientProps {
  products: Product[];
  categories: Category[];
}

export function HomeClient({ products }: HomeClientProps) {
  const { categories, selectedCategory, setSelectedCategory } = useCategory();
  const router = useRouter();

  const handleSearchClick = () => {
    router.push('/search');
  };

  return (
    <div className="space-y-8">
      <header className="space-y-4">
        <div 
          className="relative group cursor-pointer"
          onClick={handleSearchClick}
        >
          <Input 
            placeholder="Search for products, brands and more..."
            className="h-12 text-base pl-10"
            readOnly
          />
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
        </div>
        <LocationBar />
      </header>
        
      <div id="categories" className="space-y-4">
          <h2 className="text-2xl font-headline font-bold text-primary">Browse Categories</h2>
          <div className="grid grid-cols-4 md:grid-cols-6 gap-4">
              <div 
                  className="flex flex-col items-center gap-2 cursor-pointer group"
                  onClick={() => setSelectedCategory('All')}
              >
                  <Card className={`w-20 h-20 rounded-full flex items-center justify-center transition-all group-hover:border-primary ${selectedCategory === 'All' ? 'border-primary border-2' : ''}`}>
                      <CardContent className="p-0">
                          <div className="w-16 h-16 rounded-full bg-muted flex items-center justify-center">
                              <span className="text-xs font-bold">All</span>
                          </div>
                      </CardContent>
                  </Card>
                  <p className="text-sm font-medium text-center">All</p>
              </div>
              {categories.map(cat => (
                   <div 
                      key={cat.name} 
                      className="flex flex-col items-center gap-2 cursor-pointer group"
                      onClick={() => setSelectedCategory(cat.name)}
                    >
                      <Card className={`w-20 h-20 rounded-full flex items-center justify-center transition-all group-hover:border-primary ${selectedCategory === cat.name ? 'border-primary border-2' : ''}`}>
                          <CardContent className="p-0">
                               <Image 
                                  src={cat.imageUrl} 
                                  alt={cat.name}
                                  width={80}
                                  height={80}
                                  className="rounded-full object-cover w-16 h-16"
                                  data-ai-hint="category image"
                              />
                          </CardContent>
                      </Card>
                      <p className="text-sm font-medium text-center">{cat.name}</p>
                  </div>
              ))}
          </div>
      </div>

       <div className="space-y-4">
            <div className="flex items-center justify-between">
                <h1 className="text-2xl font-headline font-bold text-primary">All Products</h1>
                <SidebarTrigger />
            </div>
            <ProductGrid products={products} selectedCategory={selectedCategory} />
       </div>
    </div>
  );
}
