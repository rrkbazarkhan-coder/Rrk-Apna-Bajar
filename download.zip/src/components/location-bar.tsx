
'use client';

import { useLocation } from '@/hooks/use-location';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { MapPin, Loader2, Edit } from 'lucide-react';
import { SetAddressDialog } from './set-address-dialog';

export function LocationBar() {
  const { address, detectLocation, isDetecting } = useLocation();

  return (
    <Card className="p-3 bg-muted/50">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <MapPin className="h-5 w-5 text-primary" />
           {isDetecting ? (
             <p className="text-sm text-muted-foreground flex items-center">
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Aapki location detect ho rahi hai...
             </p>
           ) : (
             <p className="text-sm text-muted-foreground">
                Location: <span className="font-bold text-foreground">{address ? `${address.city}, ${address.pincode}` : `Set nahi hai`}</span>
             </p>
           )}
        </div>
        <div className="flex items-center gap-2">
            <Button onClick={detectLocation} disabled={isDetecting} size="sm" variant="outline">
              {isDetecting ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Detecting...
                </>
              ) : (
                'Location Fix Karein'
              )}
            </Button>
            <SetAddressDialog 
                triggerButton={
                    <Button size="sm" variant="outline">
                        <Edit className="mr-2 h-4 w-4" />
                        Change
                    </Button>
                }
            />
        </div>
      </div>
    </Card>
  );
}
