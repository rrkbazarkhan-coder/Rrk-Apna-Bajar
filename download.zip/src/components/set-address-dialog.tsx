

'use client';

import { useState, useEffect } from 'react';
import { useLocation } from '@/hooks/use-location';
import { Button } from './ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogTrigger, DialogClose } from './ui/dialog';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { useToast } from '@/hooks/use-toast';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { useApp } from '@/hooks/use-app';
import { Separator } from './ui/separator';
import type { UserAddress } from '@/lib/types';
import { LocateFixed, Loader2 } from 'lucide-react';


interface SetAddressDialogProps {
    triggerButton: React.ReactNode;
}

export function SetAddressDialog({ triggerButton }: SetAddressDialogProps) {
    const { setAddress, detectLocation, isDetecting } = useLocation();
    const { cities } = useApp();
    const { toast } = useToast();
    const [street, setStreet] = useState('');
    const [landmark, setLandmark] = useState('');
    const [city, setCity] = useState('');
    const [pincode, setPincode] = useState('');
    const [state, setState] = useState('');
    const [country, setCountry] = useState('India');
    const [isOpen, setIsOpen] = useState(false);
    
    const handleDetectClick = async () => {
        const result = await detectLocation();
        if (result.success) {
            setIsOpen(false);
        }
    }

    const handleCitySelect = (value: string) => {
        const [selectedCityName, selectedPincode] = value.split('|');
        const selectedCityData = cities.find(c => c.name === selectedCityName && c.pincode === selectedPincode);
        
        if (selectedCityData) {
            const newAddress: UserAddress = {
                street: selectedCityData.name, // Using city name as street for simplicity on quick select
                city: selectedCityData.name,
                pincode: selectedCityData.pincode,
                state: '', // You might want to add state to your city data
                country: 'India',
                lat: selectedCityData.lat,
                lng: selectedCityData.lng
            };
            setAddress(newAddress);
            toast({
                title: 'Location Updated',
                description: `Your location has been set to ${selectedCityData.name} - ${selectedCityData.pincode}.`,
            });
            setIsOpen(false);
        }
    };


    const handleSubmit = () => {
        if (!street || !city || !pincode || !state || !country) {
            toast({
                variant: 'destructive',
                title: 'All fields are required',
            });
            return;
        }

        const selectedCityData = cities.find(c => c.name.toLowerCase() === (city || '').toLowerCase() && c.pincode === pincode);

        setAddress({
            street,
            landmark,
            city,
            pincode,
            state,
            country,
            lat: selectedCityData?.lat || undefined,
            lng: selectedCityData?.lng || undefined,
        });

        toast({
            title: 'Address Set',
            description: `Your location has been manually set to ${city}.`,
        });
        setIsOpen(false);
    };
    
    return (
        <Dialog open={isOpen} onOpenChange={setIsOpen}>
            <DialogTrigger asChild>{triggerButton}</DialogTrigger>
            <DialogContent>
                <DialogHeader>
                    <DialogTitle>Set Your Delivery Address</DialogTitle>
                    <DialogDescription>
                        Quickly select your city or enter your address manually.
                    </DialogDescription>
                </DialogHeader>
                <div className="space-y-4 py-4">
                    
                    <Button onClick={handleDetectClick} disabled={isDetecting} className="w-full">
                        {isDetecting ? (
                            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        ) : (
                            <LocateFixed className="mr-2 h-4 w-4" />
                        )}
                        Detect Current Location
                    </Button>

                    <div className="relative">
                        <Separator />
                        <span className="absolute left-1/2 -top-3 -translate-x-1/2 bg-background px-2 text-sm text-muted-foreground">OR</span>
                    </div>

                    <div className="space-y-2">
                        <Label>Select your Area</Label>
                        <Select onValueChange={handleCitySelect}>
                            <SelectTrigger>
                                <SelectValue placeholder="Choose your city/area..." />
                            </SelectTrigger>
                            <SelectContent>
                                {cities.map(c => (
                                    <SelectItem key={`${c.name}-${c.pincode}`} value={`${c.name}|${c.pincode}`}>{c.name} - {c.pincode}</SelectItem>
                                ))}
                            </SelectContent>
                        </Select>
                    </div>

                    <div className="relative">
                        <Separator />
                        <span className="absolute left-1/2 -top-3 -translate-x-1/2 bg-background px-2 text-sm text-muted-foreground">OR</span>
                    </div>

                    <p className="text-sm font-medium text-center text-muted-foreground">Enter manually</p>
                    
                    <div className="space-y-2">
                        <Label htmlFor="street">Street Address / House No.</Label>
                        <Input id="street" value={street} onChange={e => setStreet(e.target.value)} placeholder="e.g., 123, Main Street" />
                    </div>
                    <div className="space-y-2">
                        <Label htmlFor="landmark">Landmark (Optional)</Label>
                        <Input id="landmark" value={landmark} onChange={e => setLandmark(e.target.value)} placeholder="e.g., Near City Mall" />
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                           <Label htmlFor="city-manual">City</Label>
                           <Input id="city-manual" value={city} onChange={e => setCity(e.target.value)} placeholder="e.g., Darbhanga" />
                        </div>
                         <div className="space-y-2">
                            <Label htmlFor="pincode">Pincode</Label>
                            <Input id="pincode" value={pincode} onChange={e => setPincode(e.target.value)} />
                        </div>
                    </div>
                     <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                            <Label htmlFor="state">State</Label>
                            <Input id="state" value={state} onChange={e => setState(e.target.value)} placeholder="e.g., Bihar" />
                        </div>
                        <div className="space-y-2">
                            <Label htmlFor="country">Country</Label>
                            <Input id="country" value={country} onChange={e => setCountry(e.target.value)} />
                        </div>
                    </div>
                    <Button onClick={handleSubmit} className="w-full">Set Address Manually</Button>
                </div>
            </DialogContent>
        </Dialog>
    )
}
