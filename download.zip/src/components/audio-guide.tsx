
'use client';

import { useState } from 'react';
import { Button } from './ui/button';
import { Volume2, Loader2 } from 'lucide-react';
import { textToSpeechAction } from '@/app/actions';
import { useToast } from '@/hooks/use-toast';

interface AudioGuideProps {
  text: string;
  buttonText?: string;
}

export function AudioGuide({ text, buttonText }: AudioGuideProps) {
  const [isLoading, setIsLoading] = useState(false);
  const [audio, setAudio] = useState<HTMLAudioElement | null>(null);
  const { toast } = useToast();

  const handlePlayAudio = async () => {
    if (audio) {
      audio.play();
      return;
    }

    setIsLoading(true);
    try {
      const result = await textToSpeechAction(text);
      if (result.success && result.audioDataUri) {
        const audioInstance = new Audio(result.audioDataUri);
        setAudio(audioInstance);
        audioInstance.play();
        audioInstance.onended = () => setIsLoading(false);
      } else {
        throw new Error(result.error || 'Failed to generate audio.');
      }
    } catch (error) {
      toast({
        title: 'Audio Guide Error',
        description: (error as Error).message,
        variant: 'destructive',
      });
      setIsLoading(false);
    }
  };
  
  if (buttonText) {
      return (
        <Button
          type="button"
          variant="outline"
          size="sm"
          onClick={handlePlayAudio}
          disabled={isLoading}
        >
            {isLoading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Volume2 className="mr-2 h-4 w-4" />}
            {buttonText}
        </Button>
      )
  }

  return (
    <Button
      type="button"
      variant="ghost"
      size="icon"
      onClick={handlePlayAudio}
      disabled={isLoading}
      className="h-6 w-6 text-muted-foreground"
    >
      {isLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Volume2 className="h-4 w-4" />}
      <span className="sr-only">Listen to guide</span>
    </Button>
  );
}
