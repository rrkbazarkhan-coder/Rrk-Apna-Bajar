

'use client';

import { useLocation } from "@/hooks/use-location";
import { ProductCard } from "@/components/product-card";
import { Product, Store } from '@/lib/types';
import { useApp } from "@/hooks/use-app";
import { getDistance } from "@/lib/utils";

interface ProductGridProps {
  products: Product[];
  selectedCategory: string;
  limit?: number;
  hideFiltering?: boolean;
}

const MAX_DISTANCE_KM = 20;

export function ProductGrid({ products, selectedCategory, limit, hideFiltering = false }: ProductGridProps) {
  const { address } = useLocation();
  const { stores } = useApp();

  // Create maps for quick lookup
  const activeStoreIds = new Set(stores.filter(s => s.status === 'active').map(s => s.id));
  const storeLocationMap = new Map(stores.map(s => [s.id, { lat: s.lat, lng: s.lng }]));

  let filteredProducts = products.filter(p => {
    // Check if store is active
    if (!activeStoreIds.has(p.storeId)) return false;

    // Check distance if user location and store location are available
    const storeLocation = storeLocationMap.get(p.storeId);
    if (address?.lat && address?.lng && storeLocation?.lat && storeLocation?.lng) {
      const distance = getDistance(address.lat, address.lng, storeLocation.lat, storeLocation.lng);
      if (distance > MAX_DISTANCE_KM) {
        return false;
      }
    } else {
        // Fallback for when location is not available - check city
        if (address?.city && p.location.toLowerCase() !== address.city.toLowerCase()) {
            return false;
        }
    }

    return true;
  });
  
  if (!hideFiltering) {
    filteredProducts = filteredProducts.filter(p => 
      (selectedCategory === 'All' || p.category === selectedCategory)
    );
  }
  
  if (limit) {
    filteredProducts = filteredProducts.slice(0, limit);
  }


  if (filteredProducts.length === 0 && !hideFiltering) {
    return (
      <div className="text-center py-16 col-span-full">
        <h2 className="text-2xl font-headline text-primary">No Products Found</h2>
        <p className="text-muted-foreground mt-2">
          There are no products available in your area for the selected category.
        </p>
        <p className="text-muted-foreground">Try changing your location or selecting another category!</p>
      </div>
    );
  }
  
  if (filteredProducts.length === 0 && hideFiltering) {
    return null;
  }

  return (
    <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-4 gap-4">
      {filteredProducts.map(product => (
        <ProductCard key={product.id} product={product} />
      ))}
    </div>
  );
}
