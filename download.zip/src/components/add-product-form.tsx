
'use client';

import { useState, useMemo } from 'react';
import { useForm, useWatch, useFieldArray } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage, FormDescription } from '@/components/ui/form';
import { useToast } from '@/hooks/use-toast';
import { Sparkles, Loader2, X, Upload, Video, PlusCircle } from 'lucide-react';
import { generateDetailsAction } from '@/app/actions';
import Image from 'next/image';
import type { Product, Category } from '@/lib/types';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from './ui/badge';
import { Switch } from './ui/switch';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogClose, DialogDescription } from './ui/dialog';
import { AudioGuide } from './audio-guide';

const colorVariantSchema = z.object({
  name: z.string().min(1, 'Color name is required'),
  imageUrl: z.string().url('Image URL is required'),
});

const productSchema = z.object({
  name: z.string().min(3, 'Product name must be at least 3 characters.'),
  mrp: z.coerce.number().optional(),
  price: z.coerce.number().min(1, 'Price must be at least 1.'),
  stock: z.coerce.number().min(0, 'Stock cannot be negative.').optional(),
  description: z.string().min(10, 'Description must be at least 10 characters.'),
  imageUrls: z.array(z.string().url()).min(1, 'At least one product image is required.').max(5, 'You can upload a maximum of 5 images.'),
  videoUrl: z.string().url().optional(),
  category: z.string().min(1, 'Category is required.'),
  sizes: z.array(z.string()).optional(),
  colors: z.array(colorVariantSchema).optional(),
  returnPolicy: z.string().optional(),
  freeDelivery: z.boolean().optional(),
}).refine(data => !data.mrp || data.price <= data.mrp, {
    message: "Selling price cannot be greater than MRP.",
    path: ["price"],
});

type ProductFormValues = z.infer<typeof productSchema>;

interface AddProductFormProps {
    onProductAdd: (product: Omit<Product, 'id' | 'storeId' | 'location' | 'status' | 'rating' | 'reviews'>) => void;
    categories: Category[];
    onCategoryAdd: (category: Category) => void;
}

const returnPolicies = ["No Returns", "3-Day Returns", "5-Day Returns", "7-Day Returns"];

function AddCategoryModal({ onCategoryAdd }: { onCategoryAdd: (category: Category) => void }) {
    const [name, setName] = useState('');
    const [imageUrl, setImageUrl] = useState('');
    const [imagePreview, setImagePreview] = useState('');

    const handleImageChange = (event: React.ChangeEvent<HTMLInputElement>) => {
        const file = event.target.files?.[0];
        if (file) {
            const reader = new FileReader();
            reader.onloadend = () => {
                const dataUrl = reader.result as string;
                setImageUrl(dataUrl);
                setImagePreview(dataUrl);
            };
            reader.readAsDataURL(file);
        }
    };

    const handleSubmit = () => {
        if (name && imageUrl) {
            onCategoryAdd({ name, imageUrl });
            setName('');
            setImageUrl('');
            setImagePreview('');
        }
    }

    return (
        <Dialog>
            <DialogTrigger asChild>
                <Button type="button" variant="outline" size="sm">
                    <PlusCircle className="mr-2 h-4 w-4" />
                    New Category
                </Button>
            </DialogTrigger>
            <DialogContent>
                <DialogHeader>
                    <DialogTitle>Create a New Category</DialogTitle>
                     <DialogDescription>
                        Enter a name and upload an image for the new category.
                    </DialogDescription>
                </DialogHeader>
                <div className="space-y-4 py-4">
                    <div>
                        <Label htmlFor="category-name">Category Name</Label>
                        <Input id="category-name" value={name} onChange={e => setName(e.target.value)} />
                    </div>
                    <div>
                        <Label htmlFor="category-image">Category Image</Label>
                        <Input id="category-image" type="file" accept="image/*" onChange={handleImageChange} />
                    </div>
                    {imagePreview && (
                        <Image src={imagePreview} alt="Category preview" width={100} height={100} className="rounded-md object-cover" />
                    )}
                    <DialogClose asChild>
                        <Button onClick={handleSubmit} disabled={!name || !imageUrl}>Create Category</Button>
                    </DialogClose>
                </div>
            </DialogContent>
        </Dialog>
    )
}


function SettlementCalculator({ control }: { control: any }) {
    const price = useWatch({ control, name: 'price' });
    const freeDelivery = useWatch({ control, name: 'freeDelivery' });

    const { commission, maintenance, shipping, settlement } = useMemo(() => {
        const p = Number(price) || 0;
        const commission = p * 0.05;
        const maintenance = p * 0.02;
        const shipping = freeDelivery ? 30 : 0;
        const settlement = p - commission - maintenance - shipping;
        return { commission, maintenance, shipping, settlement };
    }, [price, freeDelivery]);

    if (!price || price <= 0) return null;

    return (
        <Card className="bg-muted/50">
            <CardHeader className='pb-2'>
                <CardTitle className="text-base font-medium">Settlement Amount</CardTitle>
            </CardHeader>
            <CardContent className="text-sm space-y-1">
                <div className="flex justify-between">
                    <span>Selling Price:</span>
                    <span>₹{price.toLocaleString()}</span>
                </div>
                <div className="flex justify-between text-destructive">
                    <span>- Commission (5%):</span>
                    <span>₹{commission.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
                </div>
                <div className="flex justify-between text-destructive">
                    <span>- Maintenance (2%):</span>
                    <span>₹{maintenance.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
                </div>
                {freeDelivery && (
                    <div className="flex justify-between text-destructive">
                        <span>- Shipping Fee:</span>
                        <span>₹{shipping.toLocaleString()}</span>
                    </div>
                )}
                 <div className="flex justify-between font-bold border-t pt-2 mt-2">
                    <span>You will receive:</span>
                    <span>₹{settlement.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
                </div>
            </CardContent>
        </Card>
    )
}

export function AddProductForm({ onProductAdd, categories, onCategoryAdd }: AddProductFormProps) {
  const [imagePreviews, setImagePreviews] = useState<string[]>([]);
  const [videoPreview, setVideoPreview] = useState<string | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const [sizeInput, setSizeInput] = useState('');
  const { toast } = useToast();

  const form = useForm<ProductFormValues>({
    resolver: zodResolver(productSchema),
    defaultValues: {
      name: '',
      price: 0,
      stock: 1,
      description: '',
      imageUrls: [],
      category: '',
      sizes: [],
      colors: [],
      returnPolicy: returnPolicies[1],
      freeDelivery: false,
    },
  });
  
  const { fields, append, remove } = useFieldArray({
    control: form.control,
    name: 'colors',
  });

  const handleGenerateDetails = async (dataUrl: string) => {
    setIsGenerating(true);
    try {
      const result = await generateDetailsAction(dataUrl);
      if (result.success && result.details) {
        const { name, description, category, mrp } = result.details;
        form.setValue('name', name);
        form.setValue('description', description);
        if (mrp) {
            form.setValue('mrp', mrp);
        }
        
        const existingCategory = categories.find(c => c.name.toLowerCase() === category.toLowerCase());
        if(existingCategory) {
            form.setValue('category', existingCategory.name);
        } else {
            const newCategory = { name: category, imageUrl: dataUrl }; // Use product image as category image
            onCategoryAdd(newCategory);
            form.setValue('category', newCategory.name);
        }
        
        toast({
          title: 'Product Details Generated!',
          description: 'AI has filled in the name, description, and category for you.',
        });
      } else {
        throw new Error(result.error || 'Failed to generate details.');
      }
    } catch (error) {
      toast({
        title: 'Generation Failed',
        description: (error as Error).message,
        variant: 'destructive',
      });
    } finally {
      setIsGenerating(false);
    }
  };

  const handleImageChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files;
    if (files) {
      const currentImageCount = imagePreviews.length;
      if (files.length + currentImageCount > 5) {
        toast({ title: "Image Limit Exceeded", description: "You can only upload up to 5 images.", variant: "destructive" });
        return;
      }

      const newPreviews: string[] = [];
      const newUrls: string[] = form.getValues('imageUrls') || [];
      
      Array.from(files).forEach((file, index) => {
        const reader = new FileReader();
        reader.onloadend = () => {
          const dataUrl = reader.result as string;
          newPreviews.push(dataUrl);
          newUrls.push(dataUrl);

          if (newPreviews.length === files.length) {
            setImagePreviews(prev => [...prev, ...newPreviews]);
            form.setValue('imageUrls', newUrls, { shouldValidate: true });
            
            if(currentImageCount === 0 && index === 0) {
              handleGenerateDetails(dataUrl);
            }
          }
        };
        reader.readAsDataURL(file);
      });
    }
  };
  
  const removeImage = (index: number) => {
    const newPreviews = [...imagePreviews];
    const newUrls = [...(form.getValues('imageUrls') || [])];
    newPreviews.splice(index, 1);
    newUrls.splice(index, 1);
    setImagePreviews(newPreviews);
    form.setValue('imageUrls', newUrls, { shouldValidate: true });
  }
  
  const handleVideoChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const dataUrl = reader.result as string;
        form.setValue('videoUrl', dataUrl);
        setVideoPreview(dataUrl);
      };
      reader.readAsDataURL(file);
    }
  };

  const removeVideo = () => {
      setVideoPreview(null);
      form.setValue('videoUrl', undefined);
  }
  
  const onSubmit = (data: ProductFormValues) => {
    onProductAdd(data);
    toast({
        title: "Product Added!",
        description: `${data.name} has been listed in your store.`,
    });
    form.reset();
    setImagePreviews([]);
    setVideoPreview(null);
  }

  const addSize = () => {
    if (sizeInput.trim()) {
        const currentSizes = form.getValues('sizes') || [];
        form.setValue('sizes', [...currentSizes, sizeInput.trim()]);
        setSizeInput('');
    }
  }

  const removeSize = (sizeToRemove: string) => {
     const currentSizes = form.getValues('sizes') || [];
     form.setValue('sizes', currentSizes.filter(s => s !== sizeToRemove));
  }

  const handleColorImageUpload = (e: React.ChangeEvent<HTMLInputElement>, index: number) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        form.setValue(`colors.${index}.imageUrl`, event.target?.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const productFormAudioGuide = `
    प्रोडक्ट अपलोड करने के लिए कृपया यह जानकारी भरें.
    पहला, अपने प्रोडक्ट की कम से कम एक फोटो अपलोड करें. AI आपके लिए बाकी जानकारी भरने की कोशिश करेगा. आप 5 फ़ोटो तक अपलोड कर सकते हैं.
    दूसरा, आप चाहें तो एक वीडियो भी अपलोड कर सकते हैं.
    तीसरा, प्रोडक्ट का नाम जांचें और सही करें.
    चौथा, MRP और बेचने का दाम डालें.
    पांचवा, प्रोडक्ट की श्रेणी चुनें.
    छठा, प्रोडक्ट का विवरण जांचें.
    सातवां, यदि लागू हो तो साइज़ और रंग डालें.
    आठवां, अपनी रिटर्न पॉलिसी चुनें.
    अंत में, 'Add Product' बटन पर क्लिक करें.
  `;


  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
        
        <div className='flex justify-between items-center'>
            <h3 className="text-xl font-headline text-primary">Add a New Product</h3>
            <AudioGuide text={productFormAudioGuide} buttonText="Audio Guide" />
        </div>
        
        <div className='space-y-2'>
            <FormLabel>Product Media</FormLabel>
            <Card className={isGenerating ? "animate-pulse" : ""}>
                <CardContent className="p-4 space-y-4">
                    {/* Image Upload */}
                    <div className="space-y-2">
                        <Label htmlFor="image-upload">Images (up to 5)</Label>
                        <div className="p-4 border-2 border-dashed rounded-lg text-center cursor-pointer hover:bg-muted/50" onClick={() => document.getElementById('image-upload')?.click()}>
                            <div className="flex items-center justify-center text-muted-foreground">
                                {isGenerating ? (
                                    <>
                                        <Loader2 className="mr-2 h-5 w-5 animate-spin"/>
                                        <p>Analyzing Image...</p>
                                    </>
                                ) : (
                                    <>
                                        <Upload className="mr-2 h-5 w-5"/>
                                        <p>Click to upload images</p>
                                    </>
                                )}
                                
                            </div>
                        </div>
                        <Input id="image-upload" type="file" accept="image/*" onChange={handleImageChange} className="hidden" multiple disabled={isGenerating} />
                        {imagePreviews.length > 0 && (
                            <div className="grid grid-cols-3 gap-2 mt-2">
                                {imagePreviews.map((src, index) => (
                                    <div key={index} className="relative group">
                                        <Image src={src} alt={`Preview ${index+1}`} width={100} height={100} className="rounded-md w-full aspect-square object-cover" data-ai-hint="product photo"/>
                                        <button type="button" onClick={() => removeImage(index)} className="absolute top-1 right-1 bg-red-500 text-white rounded-full p-0.5 opacity-0 group-hover:opacity-100 transition-opacity">
                                            <X className="h-3 w-3"/>
                                        </button>
                                    </div>
                                ))}
                            </div>
                        )}
                        <FormField control={form.control} name="imageUrls" render={() => <FormMessage />} />
                    </div>
                     {/* Video Upload */}
                    <div className="space-y-2">
                         <Label htmlFor="video-upload">Video (optional)</Label>
                        {videoPreview ? (
                            <div className="relative group">
                                <video src={videoPreview} className="rounded-md w-full aspect-video object-cover bg-black" controls />
                                <button type="button" onClick={removeVideo} className="absolute top-2 right-2 bg-red-500 text-white rounded-full p-0.5 opacity-0 group-hover:opacity-100 transition-opacity">
                                    <X className="h-4 w-4"/>
                                </button>
                            </div>
                        ) : (
                            <div className="p-4 border-2 border-dashed rounded-lg text-center cursor-pointer hover:bg-muted/50" onClick={() => document.getElementById('video-upload')?.click()}>
                                <div className="flex items-center justify-center text-muted-foreground">
                                    <Video className="mr-2 h-5 w-5"/>
                                    <p>Click to upload a video</p>
                                </div>
                            </div>
                        )}
                        <Input id="video-upload" type="file" accept="video/*" onChange={handleVideoChange} className="hidden" />
                    </div>
                </CardContent>
            </Card>
        </div>


        <FormField
          control={form.control}
          name="name"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Product Name</FormLabel>
              <FormControl>
                <Input placeholder="e.g., Handcrafted Clay Pot" {...field} className="text-base" />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        <div className="grid grid-cols-3 gap-4">
            <FormField
            control={form.control}
            name="mrp"
            render={({ field }) => (
                <FormItem>
                <FormLabel>MRP (₹)</FormLabel>
                <FormControl>
                    <Input type="number" placeholder="e.g., 2000" {...field} className="text-base" />
                </FormControl>
                <FormMessage />
                </FormItem>
            )}
            />
            <FormField
            control={form.control}
            name="price"
            render={({ field }) => (
                <FormItem>
                <FormLabel>Selling Price (₹)</FormLabel>
                <FormControl>
                    <Input type="number" placeholder="e.g., 1500" {...field} className="text-base" />
                </FormControl>
                <FormMessage />
                </FormItem>
            )}
            />
            <FormField
            control={form.control}
            name="stock"
            render={({ field }) => (
                <FormItem>
                <FormLabel>Stock Qty</FormLabel>
                <FormControl>
                    <Input type="number" placeholder="e.g., 10" {...field} className="text-base" />
                </FormControl>
                <FormMessage />
                </FormItem>
            )}
            />
        </div>
        
        <SettlementCalculator control={form.control} />

         <FormField
          control={form.control}
          name="category"
          render={({ field }) => (
            <FormItem>
                <div className="flex justify-between items-center">
                    <FormLabel>Category</FormLabel>
                    <AddCategoryModal onCategoryAdd={onCategoryAdd} />
                </div>
                <Select onValueChange={field.onChange} value={field.value}>
                    <FormControl>
                        <SelectTrigger className="text-base">
                            <SelectValue placeholder="Select a category" />
                        </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                        {categories.map(category => (
                            <SelectItem key={category.name} value={category.name}>{category.name}</SelectItem>
                        ))}
                    </SelectContent>
                </Select>
              <FormMessage />
            </FormItem>
          )}
        />
        <FormField
          control={form.control}
          name="description"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Product Description</FormLabel>
              <FormControl>
                <Textarea placeholder="Describe your product..." {...field} rows={5} className="text-base" />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        {/* Variants */}
        <div className="space-y-2">
            <FormLabel>Sizes (Optional)</FormLabel>
            <div className="flex gap-2">
                <Input value={sizeInput} onChange={(e) => setSizeInput(e.target.value)} placeholder="e.g., M" className="text-base" />
                <Button type="button" onClick={addSize}>Add</Button>
            </div>
            <div className="flex flex-wrap gap-2">
                {form.getValues('sizes')?.map(size => (
                    <Badge key={size} variant="secondary" className="flex items-center gap-1">
                        {size}
                        <button type="button" onClick={() => removeSize(size)}><X className="h-3 w-3" /></button>
                    </Badge>
                ))}
            </div>
        </div>
        
        <div className="space-y-4">
          <FormLabel>Color Variants (Optional)</FormLabel>
          {fields.map((field, index) => (
            <Card key={field.id} className="p-4 bg-muted/50">
              <div className="flex gap-4 items-end">
                <FormField
                  control={form.control}
                  name={`colors.${index}.name`}
                  render={({ field }) => (
                    <FormItem className="flex-grow">
                      <FormLabel>Color Name</FormLabel>
                      <FormControl>
                        <Input {...field} placeholder="e.g., Red" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                 <FormField
                  control={form.control}
                  name={`colors.${index}.imageUrl`}
                  render={({ field }) => (
                     <FormItem>
                       <FormControl>
                         <>
                           <Input type="file" id={`color-image-${index}`} className="hidden" onChange={(e) => handleColorImageUpload(e, index)} accept="image/*" />
                           <label htmlFor={`color-image-${index}`} className="cursor-pointer">
                             {field.value ? (
                               <Image src={field.value} alt="color preview" width={40} height={40} className="rounded-md object-cover" />
                             ) : (
                               <div className="h-10 w-10 bg-background rounded-md flex items-center justify-center border">
                                 <Upload className="h-4 w-4" />
                               </div>
                             )}
                           </label>
                         </>
                       </FormControl>
                       <FormMessage />
                     </FormItem>
                  )}
                />

                <Button type="button" variant="destructive" size="icon" onClick={() => remove(index)}>
                  <X className="h-4 w-4" />
                </Button>
              </div>
            </Card>
          ))}
          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={() => append({ name: '', imageUrl: '' })}
          >
            <PlusCircle className="mr-2 h-4 w-4" />
            Add Color Variant
          </Button>
        </div>
        
         <FormField
          control={form.control}
          name="returnPolicy"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Return Policy</FormLabel>
                <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                        <SelectTrigger className="text-base">
                            <SelectValue placeholder="Select a return policy" />
                        </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                        {returnPolicies.map(policy => (
                            <SelectItem key={policy} value={policy}>{policy}</SelectItem>
                        ))}
                    </SelectContent>
                </Select>
              <FormMessage />
            </FormItem>
          )}
        />
        
        <FormField
          control={form.control}
          name="freeDelivery"
          render={({ field }) => (
            <FormItem className="flex flex-row items-center justify-between rounded-lg border p-3 shadow-sm">
              <div className="space-y-0.5">
                <FormLabel>Offer Free Delivery?</FormLabel>
                <FormDescription>
                  If you offer free delivery, an extra ₹30 will be deducted.
                </FormDescription>
              </div>
              <FormControl>
                <Switch
                  checked={field.value}
                  onCheckedChange={field.onChange}
                />
              </FormControl>
            </FormItem>
          )}
        />


        <Button type="submit" className="w-full" disabled={isGenerating}>
            {isGenerating && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            Add Product
        </Button>
      </form>
    </Form>
  );
}
