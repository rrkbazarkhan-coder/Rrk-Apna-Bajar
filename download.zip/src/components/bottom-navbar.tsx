
'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { Home, LayoutGrid, Search, User, Store } from 'lucide-react';
import { cn } from '@/lib/utils';
import { SidebarTrigger } from './ui/sidebar';
import { useState, useEffect } from 'react';

const navItems = [
  { href: '/', label: 'Home', icon: Home },
  { href: '/search', label: 'Search', icon: Search },
  { href: '/sell', label: 'Sell', icon: Store },
  { href: '/profile', label: 'Profile', icon: User },
];

export function BottomNavbar() {
  const pathname = usePathname();
  const [isVisible, setIsVisible] = useState(true);
  const [lastScrollY, setLastScrollY] = useState(0);

  useEffect(() => {
    const controlNavbar = () => {
      if (typeof window !== 'undefined') {
        if (window.scrollY > lastScrollY && window.scrollY > 50) { // if scroll down hide the navbar
          setIsVisible(false);
        } else { // if scroll up show the navbar
          setIsVisible(true);
        }
        setLastScrollY(window.scrollY);
      }
    };

    window.addEventListener('scroll', controlNavbar);

    return () => {
      window.removeEventListener('scroll', controlNavbar);
    };
  }, [lastScrollY]);


  return (
    <nav className={cn(
        "md:hidden fixed bottom-0 left-0 right-0 bg-background border-t shadow-t-lg z-50 transition-transform duration-300",
        isVisible ? "translate-y-0" : "translate-y-full"
    )}>
      <div className="flex justify-around h-16">
        {navItems.map((item) => {
          const isActive = pathname === item.href;
          return (
            <Link
              key={item.label}
              href={item.href}
              className={cn(
                'flex flex-col items-center justify-center w-full text-sm font-medium transition-colors',
                isActive ? 'text-primary' : 'text-muted-foreground hover:text-primary'
              )}
            >
              <item.icon className={cn("h-6 w-6 mb-1")} />
              <span>{item.label}</span>
            </Link>
          );
        })}
         <div className={cn('flex flex-col items-center justify-center w-full text-sm font-medium transition-colors text-muted-foreground hover:text-primary')}>
            <SidebarTrigger>
                 <LayoutGrid className="h-6 w-6 mb-1" />
                 <span>Categories</span>
            </SidebarTrigger>
        </div>
      </div>
    </nav>
  );
}
