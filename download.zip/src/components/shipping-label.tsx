
'use client';

import type { Order, Store } from '@/lib/types';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Separator } from './ui/separator';
import { Button } from './ui/button';
import { Printer, Package } from 'lucide-react';

interface ShippingLabelProps {
  order: Order;
  store: Store;
}

export function ShippingLabel({ order, store }: ShippingLabelProps) {
  
  const handlePrint = () => {
    window.print();
  };

  const paymentMethod = "Cash on Delivery (COD)";
  const isPrepaid = paymentMethod !== "Cash on Delivery (COD)";

  return (
    <Card>
      <style>
        {`
          @media print {
            body * {
              visibility: hidden;
            }
            #printable-label, #printable-label * {
              visibility: visible;
            }
            #printable-label {
              position: absolute;
              left: 0;
              top: 0;
              width: 100%;
              border: none;
            }
            #print-button-label {
              display: none;
            }
          }
        `}
      </style>
      <div id="printable-label" className="p-4 border-4 border-dashed rounded-lg">
        <CardHeader className="p-2 text-center">
            <CardTitle className="text-xl font-bold">{store.name}</CardTitle>
        </CardHeader>
        <Separator />
        <CardContent className="p-2">
            <div className="grid grid-cols-2 gap-2 my-2 text-sm">
                <div>
                    <h4 className="font-bold text-xs uppercase">From:</h4>
                    <p className="font-semibold">{store.sellerName}</p>
                    <p>{store.address}</p>
                    <p>{store.landmark && `Landmark: ${store.landmark}`}</p>
                    <p>{store.city}, {store.pincode}</p>
                    <p>Ph: {store.sellerPhone}</p>
                </div>
                 <div>
                    <h4 className="font-bold text-xs uppercase">To:</h4>
                    <p className="font-semibold">{order.buyerName}</p>
                    <p>{order.shippingAddress.street}</p>
                    {order.shippingAddress.landmark && <p>Landmark: {order.shippingAddress.landmark}</p>}
                    <p>{order.shippingAddress.city}, {order.shippingAddress.pincode}</p>
                </div>
            </div>
            
            <Separator />

            <div className="my-2 text-center">
                <p className="text-xs">Order ID:</p>
                <p className="font-bold text-lg">{order.id}</p>
            </div>
            
            <Separator />
            
            <div className="my-2 text-center">
                 <p className="font-bold text-2xl">{isPrepaid ? 'PREPAID' : `COD: ₹${order.total.toLocaleString()}`}</p>
            </div>

            <Separator />

            <div className="mt-2 text-center">
                <p className="text-xs">Items:</p>
                <p className="text-xs">{order.items.map(i => `${i.name} (x${i.quantity})`).join(', ')}</p>
            </div>

        </CardContent>
      </div>
      <div id="print-button-label" className="p-6 pt-2 text-center">
        <Button onClick={handlePrint}><Printer className="mr-2 h-4 w-4" /> Print Label</Button>
      </div>
    </Card>
  );
}
