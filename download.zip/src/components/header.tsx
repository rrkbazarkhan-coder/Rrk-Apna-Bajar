
'use client';

import Link from 'next/link';
import { useCart } from '@/hooks/use-cart';
import { Button } from '@/components/ui/button';
import { ShoppingCart, Store, Menu, Repeat } from 'lucide-react';
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetDescription, SheetTrigger } from '@/components/ui/sheet';
import { SidebarTrigger } from './ui/sidebar';

export function Header() {
  const { cartCount } = useCart();

  return (
    <header className="bg-background/80 backdrop-blur-sm sticky top-0 z-40 border-b">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between h-16">
        <div className="flex items-center space-x-2">
            <SidebarTrigger className="md:hidden" />
           <Link href="/" className="flex items-center space-x-2">
            <Repeat className="h-8 w-8 text-primary" />
            <span className="font-headline text-2xl font-bold text-primary">
              Rrk Apna Bajar
            </span>
          </Link>
        </div>

        <div className="flex items-center space-x-2 md:space-x-4">
            
            <nav className="hidden md:flex items-center space-x-2">
                <Button variant="ghost" asChild>
                    <Link href="/sell">
                        <Store className="mr-2 h-5 w-5" />
                        Sell
                    </Link>
                </Button>
            </nav>

            <Button variant="ghost" size="icon" asChild>
                <Link href="/cart" className="relative">
                    <ShoppingCart className="h-6 w-6" />
                    {cartCount > 0 && (
                        <span className="absolute -top-1 -right-1 bg-accent text-accent-foreground text-xs font-bold rounded-full h-4 w-4 flex items-center justify-center">
                        {cartCount}
                        </span>
                    )}
                    <span className="sr-only">Shopping Cart</span>
                </Link>
            </Button>
            
            <div className="md:hidden">
              <Sheet>
                <SheetTrigger asChild>
                  <Button variant="ghost" size="icon">
                    <Menu className="h-6 w-6" />
                    <span className="sr-only">Open menu</span>
                  </Button>
                </SheetTrigger>
                <SheetContent title="Mobile Menu">
                    <SheetHeader>
                        <SheetTitle>Menu</SheetTitle>
                        <SheetDescription>
                            Navigate through the application pages.
                        </SheetDescription>
                    </SheetHeader>
                  <nav className="flex flex-col space-y-4 text-lg mt-8">
                     <Link href="/admin" className="hover:text-primary">Admin Panel</Link>
                     <Link href="/profile" className="hover:text-primary">Profile</Link>
                     <Link href="/sell" className="hover:text-primary">Sell</Link>
                     <Link href="/cart" className="hover:text-primary">Cart</Link>
                  </nav>
                </SheetContent>
              </Sheet>
            </div>
             <Link href="/admin" className="hidden md:block text-sm font-medium hover:text-primary">Admin</Link>
        </div>
      </div>
    </header>
  );
}
