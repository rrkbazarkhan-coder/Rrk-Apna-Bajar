
'use client';

import { createContext, useState, ReactNode, useMemo, useEffect, useCallback, useContext } from 'react';
import type { Product, Store, Category, Order, City, CartItem, UserAddress } from '@/lib/types';
import {
    products as initialProducts,
    stores as initialStores,
    categories as initialCategories,
    CITIES as initialCities,
} from '@/lib/data';
import { useToast } from '@/hooks/use-toast';
import { getDistance } from '@/lib/utils';
import { SidebarProvider, Sidebar, SidebarInset } from '@/components/ui/sidebar';
import { AppSidebar } from '@/components/app-sidebar';
import { Header } from '@/components/header';
import { Footer } from '@/components/footer';
import { BottomNavbar } from '@/components/bottom-navbar';
import { Toaster } from '@/components/ui/toaster';
import { cn } from "@/lib/utils";
import { LocationPermissionGate } from './location-permission-gate';
import { Loader2 } from 'lucide-react';
import { useApp } from '@/hooks/use-app';
import { useUserLocation } from '@/hooks/use-user-location';
import { auth, signUpWithEmail as firebaseSignUp, signInWithEmail as firebaseSignIn } from '@/lib/firebase';
import { onAuthStateChanged, signOut as firebaseSignOut, type User } from 'firebase/auth';
import { useRouter, usePathname } from 'next/navigation';


// --- Context Definitions ---
export const AppContext = createContext<AppContextType | undefined>(undefined);
export const AuthContext = createContext<AuthContextType | undefined>(undefined);
export const CartContext = createContext<CartContextType | undefined>(undefined);
export const CategoryContext = createContext<CategoryContextType | undefined>(undefined);
export const LocationContext = createContext<LocationContextType | undefined>(undefined);

// --- Type Definitions ---
export interface AppContextType {
  products: Product[];
  addProduct: (product: Product) => void;
  stores: Store[];
  addStore: (store: Omit<Store, 'id' | 'createdAt'>) => void;
  updateStoreStatus: (storeId: number, status: 'active' | 'blocked') => void;
  categories: Category[];
  addCategory: (category: Category) => void;
  cities: City[];
  addCity: (city: City) => void;
  orders: Order[];
  addOrder: (order: Order) => void;
  updateOrderStatus: (orderId: string, status: Order['status']) => void;
}

export interface AuthContextType {
    user: User | null;
    loading: boolean;
    signUpWithEmail: (email: string, password: string, name: string) => Promise<void>;
    signInWithEmail: (email: string, password: string) => Promise<void>;
    signOut: () => Promise<void>;
}


export interface CartContextType {
  cart: CartItem[];
  addToCart: (product: Product, quantity?: number) => void;
  removeFromCart: (productId: number) => void;
  updateQuantity: (productId: number, quantity: number) => void;
  clearCart: () => void;
  cartCount: number;
  cartTotal: number;
}

export interface CategoryContextType {
  categories: Category[];
  addCategory: (category: Category) => void;
  selectedCategory: string;
  setSelectedCategory: (category: string) => void;
}

export interface LocationContextType {
    location: string | null;
    setLocation: (location: string | null) => void;
    address: UserAddress | null;
    setAddress: (address: UserAddress | null) => void;
    availableLocations: City[];
    detectLocation: () => Promise<{ success: boolean; location?: string; error?: string; }>;
    isDetecting: boolean;
    permissionState: PermissionState | 'loading';
    useLastKnownLocation: () => void;
    lastKnownLocation: string | null;
}

// --- App Provider ---
function AppProvider({ children }: { children: ReactNode }) {
  const [products, setProducts] = useState<Product[]>([]);
  const [stores, setStores] = useState<Store[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [cities, setCities] = useState<City[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);

  const [isClient, setIsClient] = useState(false);

  useEffect(() => {
    setIsClient(true);
  }, []);

  const getFromLocalStorage = <T,>(key: string, fallback: T): T => {
    if (!isClient) return fallback;
    try {
      const storedValue = localStorage.getItem(key);
      return storedValue ? JSON.parse(storedValue) : fallback;
    } catch (error) {
      console.error(`Error reading from localStorage key “${key}”:`, error);
      return fallback;
    }
  };
  
   useEffect(() => {
    if (isClient) {
      setProducts(getFromLocalStorage('products', initialProducts));
      setStores(getFromLocalStorage('stores', initialStores));
      setCategories(getFromLocalStorage('categories', initialCategories));
      setCities(getFromLocalStorage('cities', initialCities));
      setOrders(getFromLocalStorage('orders', []));
    }
  }, [isClient]);

  const useLocalStorage = <T,>(key: string, state: T) => {
    useEffect(() => {
      if (isClient) {
        localStorage.setItem(key, JSON.stringify(state));
      }
    }, [state, isClient, key]);
  };
  
  useLocalStorage('products', products);
  useLocalStorage('stores', stores);
  useLocalStorage('categories', categories);
  useLocalStorage('cities', cities);
  useLocalStorage('orders', orders);

  const addProduct = (product: Product) => setProducts(prev => [product, ...prev]);
  const addStore = (store: Omit<Store, 'id' | 'createdAt'>) => {
    setStores(prev => {
        const newStore: Store = {
            ...store,
            id: (prev.length > 0 ? Math.max(...prev.map(s => s.id)) : 0) + 1,
            status: 'active' as const,
            createdAt: new Date().toISOString(),
        };
        const newStores = [...prev, newStore];
        return newStores;
    });
  };
  const updateStoreStatus = useCallback((storeId: number, status: 'active' | 'blocked') => {
    setStores(prev => prev.map(s => (s.id === storeId ? { ...s, status } : s)));
  }, []);
  const addCategory = (category: Category) => {
    setCategories(prev => {
        if (prev.some(c => c.name.toLowerCase() === category.name.toLowerCase())) return prev;
        return [...prev, category];
    });
  };
  const addCity = (city: City) => {
    setCities(prev => {
        if (prev.some(c => c.name.toLowerCase() === city.name.toLowerCase())) return prev;
        return [...prev, { ...city, lat: city.lat || 0, lng: city.lng || 0 }];
    });
  };
  const addOrder = (order: Order) => setOrders(prev => [order, ...prev]);

  const updateOrderStatus = (orderId: string, status: Order['status']) => {
    setOrders(prev => prev.map(o => o.id === orderId ? { ...o, status } : o));
  };


  const value = useMemo(() => ({
    products, addProduct, stores, addStore, updateStoreStatus, categories, addCategory, cities, addCity, orders, addOrder, updateOrderStatus
  }), [products, stores, categories, cities, orders, updateStoreStatus, addOrder]);

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}

// --- Auth Provider ---
function AuthProvider({ children }: { children: ReactNode }) {
    const [user, setUser] = useState<User | null>(null);
    const [loading, setLoading] = useState(true);
    const router = useRouter();
    const pathname = usePathname();

    useEffect(() => {
        const unsubscribe = onAuthStateChanged(auth, (user) => {
            setUser(user);
            setLoading(false);
        });

        return () => unsubscribe();
    }, []);

    const signOut = async () => {
        await firebaseSignOut(auth);
        router.push('/login');
    };
    
    const value = useMemo(() => ({
        user,
        loading,
        signUpWithEmail: firebaseSignUp,
        signInWithEmail: firebaseSignIn,
        signOut
    }), [user, loading]);

    // This effect handles routing based on auth state
    useEffect(() => {
        if (loading) return; // Don't do anything while loading
        
        const isAuthPage = pathname === '/login';

        if (!user && !isAuthPage) {
            // If not logged in and not on login page, redirect to login
            router.push('/login');
        } else if (user && isAuthPage) {
            // If logged in and on login page, redirect to home
            router.push('/');
        }

    }, [user, loading, pathname, router]);

    if (loading) {
         return (
            <div className="flex justify-center items-center min-h-screen">
                <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
        );
    }
    
    // Allow rendering login page even if user is not set
    if (!user && pathname !== '/login') {
        // While redirecting, show a loader
        return (
             <div className="flex justify-center items-center min-h-screen">
                <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
        );
    }

    return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

// --- Cart Provider ---
function CartProvider({ children }: { children: ReactNode }) {
  const [cart, setCart] = useState<CartItem[]>([]);
  const { toast } = useToast();

  const [isClient, setIsClient] = useState(false);
  useEffect(() => { setIsClient(true) }, []);

  useEffect(() => {
    if (isClient) {
      const storedCart = localStorage.getItem('cart');
      if (storedCart) {
        setCart(JSON.parse(storedCart));
      }
    }
  }, [isClient]);

  useEffect(() => {
    if(isClient) {
      localStorage.setItem('cart', JSON.stringify(cart));
    }
  }, [cart, isClient]);


  const addToCart = (product: Product, quantity = 1) => {
    setCart(prevCart => {
      const existingItem = prevCart.find(item => item.product.id === product.id);
      if (existingItem) {
        return prevCart.map(item => item.product.id === product.id ? { ...item, quantity: item.quantity + quantity } : item);
      }
      return [...prevCart, { product, quantity }];
    });
    toast({ title: "Added to cart", description: `${product.name} has been added to your cart.` });
  };
  const removeFromCart = (productId: number) => {
    setCart(prevCart => prevCart.filter(item => item.product.id !== productId));
    toast({ title: "Item removed", description: "The item has been removed from your cart.", variant: 'destructive' });
  };
  const updateQuantity = (productId: number, quantity: number) => {
    if (quantity <= 0) { removeFromCart(productId); return; }
    setCart(prevCart => prevCart.map(item => item.product.id === productId ? { ...item, quantity } : item));
  };
  const clearCart = () => setCart([]);
  const cartCount = useMemo(() => cart.reduce((count, item) => count + item.quantity, 0), [cart]);
  const cartTotal = useMemo(() => cart.reduce((total, item) => total + item.product.price * item.quantity, 0), [cart]);
  const value = { cart, addToCart, removeFromCart, updateQuantity, clearCart, cartCount, cartTotal };

  return <CartContext.Provider value={value}>{children}</CartContext.Provider>;
}

// --- Category Provider ---
function CategoryProvider({ children }: { children: ReactNode }) {
  const app = useApp();
  if (!app) {
      return <div className="flex flex-col items-center justify-center min-h-screen">
          <Loader2 className="mr-2 h-8 w-8 animate-spin" />
          <p>Loading categories...</p>
      </div>;
  }
  const { categories, addCategory } = app;
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const value = useMemo(() => ({ categories, addCategory, selectedCategory, setSelectedCategory }), [categories, addCategory, selectedCategory]);
  return <CategoryContext.Provider value={value}>{children}</CategoryContext.Provider>;
}


// --- Location Provider ---
function LocationProvider({ children }: { children: ReactNode }) {
    const app = useApp();
    const { toast } = useToast();
    const { location: userCoords, error: userCoordsError } = useUserLocation();
    const [location, setLocation] = useState<string | null>(null);
    const [address, setAddress] = useState<UserAddress | null>(null);
    const [isDetecting, setIsDetecting] = useState(false);
    const [permissionState, setPermissionState] = useState<PermissionState | 'loading'>('loading');
    const [lastKnownLocation, setLastKnownLocation] = useState<string | null>(null);
    
    const cities = app?.cities || [];

    const handleSetAddress = useCallback((newAddress: UserAddress | null) => {
        if (newAddress) {
        setAddress(newAddress);
        setLocation(newAddress.city);
        localStorage.setItem('userAddress', JSON.stringify(newAddress));
        setLastKnownLocation(newAddress.city);
        toast({
            title: "Location Set!",
            description: `Aapki location ${newAddress.city} set ho gayi hai.`,
        });
        } else {
        setAddress(null);
        setLocation(null);
        localStorage.removeItem('userAddress');
        }
    }, [toast]);

    const detectLocation = useCallback(async (): Promise<{ success: boolean; location?: string; error?: string; }> => {
        if (!userCoords || cities.length === 0) {
        toast({ variant: 'destructive', title: "Geolocation Not Supported", description: "Your browser does not support location services." });
        setIsDetecting(false);
        return { success: false, error: "Geolocation is not supported." };
        }
        setIsDetecting(true);
        try {
        const { lat, lng } = userCoords;
        
        const citiesWithDistance = cities.map(city => {
            if (!city.lat || !city.lng) return { ...city, distance: Infinity };
            const distance = getDistance(lat, lng, city.lat, city.lng);
            return { ...city, distance };
        });
        
        const closestCity = citiesWithDistance.reduce((closest, city) => city.distance < closest.distance ? city : closest);

        if (closestCity && closestCity.distance < 30) { // Check if closest city is within 30km
            const newAddress: UserAddress = { street: 'Detected via GPS', city: closestCity.name, pincode: closestCity.pincode, lat, lng, state: '' };
            handleSetAddress(newAddress);
            setIsDetecting(false);
            return { success: true, location: closestCity.name };
        } else {
            throw new Error("Aapke nazdeek koi serviceable city nahi mili.");
        }
        } catch (err: unknown) {
            const error = err as GeolocationPositionError | Error;
            let errorMessage = "Location detect nahi hua. Kripya phir se try karein ya map par address select karein.";

            if (err instanceof Error && err.message.includes('serviceable')) {
                errorMessage = err.message;
            } else if (userCoordsError) {
                errorMessage = userCoordsError;
            }
            
            toast({ variant: 'destructive', title: "Location Nahi Mila", description: errorMessage });
            
            setIsDetecting(false);
            return { success: false, error: errorMessage };
        }
    }, [cities, handleSetAddress, toast, userCoords, userCoordsError]);

    useEffect(() => {
        const storedAddress = localStorage.getItem('userAddress');
        if (storedAddress) {
        try {
            const parsedAddress: UserAddress = JSON.parse(storedAddress);
            setAddress(parsedAddress);
            setLocation(parsedAddress.city);
            setLastKnownLocation(parsedAddress.city);
        } catch (e) {
            localStorage.removeItem('userAddress');
        }
        } else if (cities.length > 0) {
            // Set a default if no address is stored
            const defaultCity = cities.find(c => c.name === 'Darbhanga') || cities[0];
             const defaultAddress: UserAddress = {
                street: defaultCity.name, city: defaultCity.name, pincode: defaultCity.pincode, state: 'Bihar',
                country: 'India', lat: defaultCity.lat, lng: defaultCity.lng
            };
            // Do not set it automatically, let the user choose
            // setAddress(defaultAddress); 
            // setLocation(defaultAddress.city);
        }
    }, [app, cities]);

    useEffect(() => {
        if (navigator.permissions) {
        navigator.permissions.query({ name: 'geolocation' }).then((result) => {
            setPermissionState(result.state);
            result.onchange = () => setPermissionState(result.state);
        });
        } else {
        setPermissionState('prompt'); // Fallback for older browsers
        }
    }, []);

    const useLastKnownLocation = useCallback(() => {
        const storedAddress = localStorage.getItem('userAddress');
        if (storedAddress) {
            try {
                const parsedAddress = JSON.parse(storedAddress);
                handleSetAddress(parsedAddress);
            } catch (e) {
                // If stored address is invalid, do nothing
            }
        }
    }, [handleSetAddress]);

    const value = useMemo(() => ({
        location, setLocation: handleSetAddress as any, address, setAddress: handleSetAddress, availableLocations: cities, detectLocation, isDetecting, permissionState, useLastKnownLocation, lastKnownLocation
    }), [location, address, cities, detectLocation, isDetecting, permissionState, handleSetAddress, useLastKnownLocation, lastKnownLocation]);
    
    if (!address) {
        return (
            <LocationContext.Provider value={value}>
                <div className="min-h-screen bg-background flex items-center justify-center p-4">
                    <LocationPermissionGate />
                </div>
            </LocationContext.Provider>
        )
    }

    return (
        <LocationContext.Provider value={value}>
            {children}
        </LocationContext.Provider>
    );
}


// --- Main ClientProviders Component ---
export function ClientProviders({ children }: { children: ReactNode }) {
  return (
    <AppProvider>
        <LocationProvider>
            <AuthProvider>
                <CartProvider>
                    <CategoryProvider>
                        <div className={cn('font-body antialiased')}>
                            <SidebarProvider>
                            <Sidebar>
                                <AppSidebar />
                            </Sidebar>
                            <SidebarInset>
                                <Header />
                                <main className="flex-grow container mx-auto px-4 sm:px-6 lg:px-8 py-8 pb-24 md:pb-8">
                                {children}
                                </main>
                                <Footer />
                                <BottomNavbar />
                                <Toaster />
                            </SidebarInset>
                            </SidebarProvider>
                        </div>
                    </CategoryProvider>
                </CartProvider>
            </AuthProvider>
        </LocationProvider>
    </AppProvider>
  );
}

    
