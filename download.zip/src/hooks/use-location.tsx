
'use client';

import { useContext } from 'react';
import { LocationContext, type LocationContextType } from '@/components/client-providers';


export function useLocation(): LocationContextType {
  const context = useContext(LocationContext);
  if (context === undefined) {
    throw new Error('useLocation must be used within a LocationProvider');
  }
  return context;
}
