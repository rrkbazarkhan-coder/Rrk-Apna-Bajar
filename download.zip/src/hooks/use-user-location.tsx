
'use client';

import { useEffect, useState } from "react";

export function useUserLocation() {
  const [location, setLocation] = useState<{lat:number, lng:number} | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (typeof window !== "undefined" && navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          setLocation({
            lat: pos.coords.latitude,
            lng: pos.coords.longitude,
          });
        },
        (err) => {
          console.error("Location error:", err);
          setError(err.message);
        }
      );
    } else {
        setError("Geolocation is not supported by this browser.");
    }
  }, []);

  return { location, error };
}
